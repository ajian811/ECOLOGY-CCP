CREATE TRIGGER TRI_IMPORTEXPENSE
  AFTER INSERT
  ON FNAACCOUNTLOG
  FOR EACH ROW
  declare relatedcrm_1 integer; relatedprj_1 integer; organizationid_1 integer; occurdate_1 char(10); amount_1 number(15,3); subject_1 integer; requestid_1 integer; iscontract_1 integer; description_1 varchar2(4000); begin iscontract_1 := :new.iscontractid; if(iscontract_1 =0 or iscontract_1 is null) then subject_1  := :new.feetypeid; organizationid_1  := :new.resourceid; relatedcrm_1  := :new.crmid; relatedprj_1  := :new.projectid; occurdate_1  := :new.occurdate; amount_1  := :new.amount; requestid_1  := :new.releatedid; insert into fnaexpenseinfo(subject,organizationtype,organizationid,relatedcrm,relatedprj,amount,occurdate,requestid,status,type,description) values(subject_1,3,organizationid_1,relatedcrm_1,relatedprj_1,amount_1,occurdate_1,requestid_1,1,2,description_1); end if; end;
/

