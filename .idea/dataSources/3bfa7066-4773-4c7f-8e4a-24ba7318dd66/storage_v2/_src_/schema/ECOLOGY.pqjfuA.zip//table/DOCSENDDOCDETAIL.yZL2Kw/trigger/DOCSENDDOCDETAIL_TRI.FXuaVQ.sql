CREATE TRIGGER DOCSENDDOCDETAIL_TRI
  BEFORE INSERT
  ON DOCSENDDOCDETAIL
  FOR EACH ROW
  begin select DocSendDocDetail_id.nextval into :new.id from dual; end;
/

