CREATE TRIGGER CRM_CUSTOMERTAG_ID_TRI
  BEFORE INSERT
  ON CRM_CUSTOMERTAG
  FOR EACH ROW
  begin select CRM_CustomerTag_id.nextval into :new.id from dual; end;
/

