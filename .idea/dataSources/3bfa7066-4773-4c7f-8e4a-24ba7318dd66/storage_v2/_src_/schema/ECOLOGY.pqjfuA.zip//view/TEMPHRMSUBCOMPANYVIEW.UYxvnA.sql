CREATE VIEW TEMPHRMSUBCOMPANYVIEW AS
  select HrmSubCompany.id, HrmSubCompany.subcompanyname, HrmSubCompany.subcompanydesc, HrmSubCompany.companyid, HrmSubCompany.supsubcomid, HrmSubCompany.url, HrmSubCompany.showorder, HrmSubCompany.canceled, HrmSubCompany.subcompanycode, level templevel from HrmSubCompany start with nvl(supsubcomid,0) = 0 connect by prior id=supsubcomid

/

