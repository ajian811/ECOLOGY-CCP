CREATE TRIGGER MODEDATASHARE_42_TRI
  BEFORE INSERT
  ON MODEDATASHARE_42
  FOR EACH ROW
  begin   select modeDataShare_42_id.nextval into :new.id from dual;   end;
/

