CREATE TRIGGER FNATRANSACTIONDETAIL_TRIGGER
  BEFORE INSERT
  ON FNATRANSACTIONDETAIL
  FOR EACH ROW
  begin select FnaTransactionDetail_id.nextval into :new.id from dual; end;
/

