CREATE TRIGGER DOCMARK_TRIGGER
  BEFORE INSERT
  ON DOCMARK
  FOR EACH ROW
  begin select DocMark_id.nextval into :new.id from dual; end ;
/

