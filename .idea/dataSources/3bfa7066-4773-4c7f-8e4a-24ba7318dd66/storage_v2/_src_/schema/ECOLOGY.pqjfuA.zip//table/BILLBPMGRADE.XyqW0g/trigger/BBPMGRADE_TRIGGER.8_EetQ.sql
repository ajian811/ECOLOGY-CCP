CREATE TRIGGER BBPMGRADE_TRIGGER
  BEFORE INSERT
  ON BILLBPMGRADE
  FOR EACH ROW
  begin select BBPMGrade_id.nextval into :new.id from dual; end;
/

