CREATE TRIGGER ELEMENTSHAREINFO_TRIGGER
  BEFORE INSERT
  ON ELEMENTSHAREINFO
  FOR EACH ROW
  begin select elementshareinfo_seq.nextval into :new.id from dual; end;
/

