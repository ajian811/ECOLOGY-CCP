CREATE TRIGGER BLOG_VISIT_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_VISIT
  FOR EACH ROW
  begin select blog_visit_id.nextval into :new.id from dual; end;
/

