CREATE TRIGGER TR_CPCCHANGENOTICE
  BEFORE INSERT
  ON CPCCHANGENOTICE
  FOR EACH ROW
  begin select sq_cpcchangenotice.nextval into :new.id from dual; end;
/

