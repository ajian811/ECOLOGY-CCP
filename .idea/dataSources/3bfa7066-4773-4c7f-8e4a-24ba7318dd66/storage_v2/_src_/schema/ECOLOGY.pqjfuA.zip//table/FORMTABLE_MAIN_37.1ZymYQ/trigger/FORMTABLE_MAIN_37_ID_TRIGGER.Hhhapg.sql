CREATE TRIGGER FORMTABLE_MAIN_37_ID_TRIGGER
  BEFORE INSERT
  ON FORMTABLE_MAIN_37
  FOR EACH ROW
  begin select formtable_main_37_Id.nextval into :new.id from dual; end;
/

