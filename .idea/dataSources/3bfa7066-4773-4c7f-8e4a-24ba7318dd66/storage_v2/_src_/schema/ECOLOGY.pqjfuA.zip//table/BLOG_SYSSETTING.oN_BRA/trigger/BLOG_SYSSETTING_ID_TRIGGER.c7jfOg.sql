CREATE TRIGGER BLOG_SYSSETTING_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_SYSSETTING
  FOR EACH ROW
  begin select blog_sysSetting_id.nextval into :new.id from dual; end;
/

