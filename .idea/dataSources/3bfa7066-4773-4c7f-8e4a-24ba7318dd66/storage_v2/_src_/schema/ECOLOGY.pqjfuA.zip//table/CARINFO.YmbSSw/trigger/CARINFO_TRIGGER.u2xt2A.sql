CREATE TRIGGER CARINFO_TRIGGER
  BEFORE INSERT
  ON CARINFO
  FOR EACH ROW
  begin select CarInfo_id.nextval into :new.id from dual; end ;
/

