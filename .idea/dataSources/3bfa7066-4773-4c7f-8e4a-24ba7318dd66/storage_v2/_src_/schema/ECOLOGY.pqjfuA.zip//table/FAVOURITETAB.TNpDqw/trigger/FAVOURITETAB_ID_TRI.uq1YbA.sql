CREATE TRIGGER FAVOURITETAB_ID_TRI
  BEFORE INSERT
  ON FAVOURITETAB
  FOR EACH ROW
  begin select favouritetab_id.nextval into :new.id from dual; end;
/

