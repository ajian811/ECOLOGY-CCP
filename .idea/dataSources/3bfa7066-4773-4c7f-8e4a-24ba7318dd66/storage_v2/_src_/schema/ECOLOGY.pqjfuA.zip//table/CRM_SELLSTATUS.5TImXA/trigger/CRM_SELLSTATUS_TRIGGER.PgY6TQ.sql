CREATE TRIGGER CRM_SELLSTATUS_TRIGGER
  BEFORE INSERT
  ON CRM_SELLSTATUS
  FOR EACH ROW
  begin select CRM_SellStatus_id.nextval into :new.id from dual; end;
/

