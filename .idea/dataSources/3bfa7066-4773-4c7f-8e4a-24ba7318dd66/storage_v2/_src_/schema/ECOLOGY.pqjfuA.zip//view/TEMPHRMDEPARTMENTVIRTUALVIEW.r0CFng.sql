CREATE VIEW TEMPHRMDEPARTMENTVIRTUALVIEW AS
  select id, supdepid, ((select templevel from tempHrmSubCompanyVirtualView where HrmDepartmentVirtual.subcompanyid1 = tempHrmSubCompanyVirtualView.id) + level) templevel from HrmDepartmentVirtual start with nvl(supdepid,0) = 0 connect by prior id = supdepid

/

