CREATE TRIGGER CUS_FIELDDATA_TRIGGER
  BEFORE INSERT
  ON CUS_FIELDDATA
  FOR EACH ROW
  begin select cus_fielddata_seqorder.nextval into :new.seqorder from dual; end;
/

