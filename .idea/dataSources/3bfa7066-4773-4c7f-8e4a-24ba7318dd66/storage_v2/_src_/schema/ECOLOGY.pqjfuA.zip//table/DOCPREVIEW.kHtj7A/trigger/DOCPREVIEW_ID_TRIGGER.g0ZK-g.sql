CREATE TRIGGER DOCPREVIEW_ID_TRIGGER
  BEFORE INSERT
  ON DOCPREVIEW
  FOR EACH ROW
  begin select DocPreview_id.nextval into :new.id from dual; end;
/

