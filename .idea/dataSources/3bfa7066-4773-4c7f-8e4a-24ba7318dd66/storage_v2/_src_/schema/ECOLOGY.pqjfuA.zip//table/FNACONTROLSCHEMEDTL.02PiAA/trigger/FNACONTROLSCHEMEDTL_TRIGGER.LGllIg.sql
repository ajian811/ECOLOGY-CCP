CREATE TRIGGER FNACONTROLSCHEMEDTL_TRIGGER
  BEFORE INSERT
  ON FNACONTROLSCHEMEDTL
  FOR EACH ROW
  begin select seq_fnaControlSchemeDtl_id.nextval into :new.id from dual; end;
/

