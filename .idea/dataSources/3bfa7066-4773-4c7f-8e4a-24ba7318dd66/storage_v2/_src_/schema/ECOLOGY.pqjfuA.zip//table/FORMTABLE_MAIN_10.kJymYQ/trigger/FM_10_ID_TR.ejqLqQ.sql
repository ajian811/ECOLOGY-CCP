CREATE TRIGGER FM_10_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_10
  FOR EACH ROW
  begin 
   select fm_10_ID.nextval into :new.id from dual; 
 end;
/

