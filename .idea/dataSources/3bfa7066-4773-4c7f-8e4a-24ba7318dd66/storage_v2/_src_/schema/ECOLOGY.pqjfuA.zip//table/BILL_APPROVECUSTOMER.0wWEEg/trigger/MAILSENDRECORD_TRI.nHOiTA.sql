CREATE TRIGGER MAILSENDRECORD_TRI
  BEFORE INSERT
  ON BILL_APPROVECUSTOMER
  FOR EACH ROW
  begin select MailSendRecord_id.nextval into :new.id from dual; end;
/

