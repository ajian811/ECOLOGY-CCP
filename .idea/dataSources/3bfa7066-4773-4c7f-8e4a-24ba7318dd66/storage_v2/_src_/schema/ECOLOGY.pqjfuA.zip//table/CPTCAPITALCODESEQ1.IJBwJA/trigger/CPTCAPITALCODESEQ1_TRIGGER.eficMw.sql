CREATE TRIGGER CPTCAPITALCODESEQ1_TRIGGER
  BEFORE INSERT
  ON CPTCAPITALCODESEQ1
  FOR EACH ROW
  begin select cptcapitalcodeseq1_ID.nextval into :new.id from dual; end;
/

