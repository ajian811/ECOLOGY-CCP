CREATE TRIGGER ET_LEVELDETAIL_ID_TRIGGER
  BEFORE INSERT
  ON CRM_EVALUATION_LEVELDETAIL
  FOR EACH ROW
  begin select Evaluation_LevelDetail_id.nextval into :new.id from dual; end;
/

