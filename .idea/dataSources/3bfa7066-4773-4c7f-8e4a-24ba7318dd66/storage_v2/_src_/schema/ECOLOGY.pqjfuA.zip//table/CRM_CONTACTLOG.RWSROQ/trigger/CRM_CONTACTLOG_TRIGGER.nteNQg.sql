CREATE TRIGGER CRM_CONTACTLOG_TRIGGER
  BEFORE INSERT
  ON CRM_CONTACTLOG
  FOR EACH ROW
  begin select CRM_ContactLog_id.nextval into :new.id from dual; end;
/

