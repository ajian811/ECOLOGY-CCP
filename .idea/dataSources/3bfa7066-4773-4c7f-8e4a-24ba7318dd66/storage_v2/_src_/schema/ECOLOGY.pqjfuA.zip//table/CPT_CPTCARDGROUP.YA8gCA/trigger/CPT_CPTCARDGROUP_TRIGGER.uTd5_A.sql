CREATE TRIGGER CPT_CPTCARDGROUP_TRIGGER
  BEFORE INSERT
  ON CPT_CPTCARDGROUP
  FOR EACH ROW
  begin select cpt_cptcardgroup_ID.nextval into :new.id from dual; end;
/

