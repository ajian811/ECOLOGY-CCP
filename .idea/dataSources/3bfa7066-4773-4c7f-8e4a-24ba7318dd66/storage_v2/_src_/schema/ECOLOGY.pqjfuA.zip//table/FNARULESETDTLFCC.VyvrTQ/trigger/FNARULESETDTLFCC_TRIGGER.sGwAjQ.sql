CREATE TRIGGER FNARULESETDTLFCC_TRIGGER
  BEFORE INSERT
  ON FNARULESETDTLFCC
  FOR EACH ROW
  begin select seq_FnaRuleSetDtlFcc_id.nextval into :new.id from dual; end;
/

