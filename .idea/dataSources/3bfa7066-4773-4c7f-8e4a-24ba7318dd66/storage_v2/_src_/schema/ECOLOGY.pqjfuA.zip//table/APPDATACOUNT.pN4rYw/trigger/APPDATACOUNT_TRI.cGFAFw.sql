CREATE TRIGGER APPDATACOUNT_TRI
  BEFORE INSERT
  ON APPDATACOUNT
  FOR EACH ROW
  begin select appdatacount_id.nextval into :new.id from dual; end;
/

