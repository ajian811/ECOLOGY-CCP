CREATE TRIGGER DOCWEBCOMMENT_TRIGGER
  BEFORE INSERT
  ON DOCWEBCOMMENT
  FOR EACH ROW
  begin select DocWebComment_id.nextval into :new.id from dual; end;
/

