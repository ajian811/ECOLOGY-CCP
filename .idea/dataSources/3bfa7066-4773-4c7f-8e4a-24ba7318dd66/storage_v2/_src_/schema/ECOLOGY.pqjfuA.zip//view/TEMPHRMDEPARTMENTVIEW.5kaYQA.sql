CREATE VIEW TEMPHRMDEPARTMENTVIEW AS
  select id, supdepid, ((select templevel from tempHrmSubCompanyView where HrmDepartment.subcompanyid1 = tempHrmSubCompanyView.id) + level) templevel from HrmDepartment start with nvl(supdepid,0) = 0 connect by prior id = supdepid

/

