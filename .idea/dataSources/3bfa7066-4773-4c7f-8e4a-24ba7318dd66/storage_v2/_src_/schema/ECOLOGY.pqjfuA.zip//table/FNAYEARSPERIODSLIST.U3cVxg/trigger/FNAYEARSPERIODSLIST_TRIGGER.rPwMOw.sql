CREATE TRIGGER FNAYEARSPERIODSLIST_TRIGGER
  BEFORE INSERT
  ON FNAYEARSPERIODSLIST
  FOR EACH ROW
  begin select FnaYearsPeriodsList_id.nextval into :new.id from dual; end;
/

