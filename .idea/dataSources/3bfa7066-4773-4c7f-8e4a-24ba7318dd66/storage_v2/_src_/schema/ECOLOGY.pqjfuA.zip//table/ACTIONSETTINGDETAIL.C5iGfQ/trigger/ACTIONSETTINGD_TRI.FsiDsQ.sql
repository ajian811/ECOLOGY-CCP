CREATE TRIGGER ACTIONSETTINGD_TRI
  BEFORE INSERT
  ON ACTIONSETTINGDETAIL
  FOR EACH ROW
  begin select actionsettingd_seq.nextval into :new.id from dual; end;
/

