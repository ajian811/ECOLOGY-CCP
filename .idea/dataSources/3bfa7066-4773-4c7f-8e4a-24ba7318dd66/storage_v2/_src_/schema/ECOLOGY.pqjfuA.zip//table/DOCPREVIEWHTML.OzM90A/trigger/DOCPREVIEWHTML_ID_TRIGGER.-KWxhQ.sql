CREATE TRIGGER DOCPREVIEWHTML_ID_TRIGGER
  BEFORE INSERT
  ON DOCPREVIEWHTML
  FOR EACH ROW
  begin select DocPreviewHtml_id.nextval into :new.id from dual; end;
/

