CREATE TRIGGER MODEDATASHARE_42_SET_TRI
  BEFORE INSERT
  ON MODEDATASHARE_42_SET
  FOR EACH ROW
  begin   select modeDataShare_42_set_id.nextval into :new.id from dual;   end;
/

