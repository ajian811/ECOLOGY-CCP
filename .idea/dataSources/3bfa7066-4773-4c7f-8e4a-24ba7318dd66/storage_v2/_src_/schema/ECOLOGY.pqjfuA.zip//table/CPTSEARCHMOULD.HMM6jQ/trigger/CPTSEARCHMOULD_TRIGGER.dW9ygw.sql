CREATE TRIGGER CPTSEARCHMOULD_TRIGGER
  BEFORE INSERT
  ON CPTSEARCHMOULD
  FOR EACH ROW
  begin select CptSearchMould_id.nextval into :new.id from dual; end;
/

