CREATE TRIGGER BILL_HRMFINANCE_TRIGGER
  BEFORE INSERT
  ON BILL_HRMFINANCE
  FOR EACH ROW
  begin select bill_HrmFinance_id.nextval INTO :new.id from dual; select 0 INTO :new.resourceid from dual; end;
/

