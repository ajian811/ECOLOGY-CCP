CREATE TRIGGER DOCSECCATEGORY_TRIGGER
  BEFORE INSERT
  ON DOCSECCATEGORY
  FOR EACH ROW
  begin select DocSecCategory_id.nextval INTO :new.id from dual; end;
/

