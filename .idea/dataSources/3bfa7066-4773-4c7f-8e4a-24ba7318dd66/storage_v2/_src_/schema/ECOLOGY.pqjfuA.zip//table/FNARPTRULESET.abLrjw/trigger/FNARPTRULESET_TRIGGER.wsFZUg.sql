CREATE TRIGGER FNARPTRULESET_TRIGGER
  BEFORE INSERT
  ON FNARPTRULESET
  FOR EACH ROW
  begin select seq_fnaRptRuleSet_id.nextval into :new.id from dual; end;
/

