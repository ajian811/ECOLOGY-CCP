CREATE TRIGGER BILL_FBGETAPPLY_TRI
  BEFORE INSERT
  ON BILL_FNABUDGETCHGAPPLY
  FOR EACH ROW
  begin select Bill_FBgetApply_id.nextval into :new.id from dual; end;
/

