CREATE TRIGGER CUSTOMRESOURCEOUT_TRIGGER
  BEFORE INSERT
  ON CUSTOMRESOURCEOUT
  FOR EACH ROW
  begin select customresourceout_id.nextval INTO :new.id from dual; end;
/

