CREATE TRIGGER CRM_PAYINFO_TRIGGER
  BEFORE INSERT
  ON CRM_PAYINFO
  FOR EACH ROW
  begin select CRM_PayInfo_id.nextval INTO :new.id from dual; end;
/

