CREATE TRIGGER COWORK_MAINTYPES_TRIGGER
  BEFORE INSERT
  ON COWORK_MAINTYPES
  FOR EACH ROW
  begin select cowork_maintypes_id.nextval into :new.id from dual; end;
/

