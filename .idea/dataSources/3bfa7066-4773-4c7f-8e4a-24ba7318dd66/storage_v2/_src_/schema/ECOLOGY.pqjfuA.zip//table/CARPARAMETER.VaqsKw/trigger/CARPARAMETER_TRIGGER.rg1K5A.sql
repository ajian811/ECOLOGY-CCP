CREATE TRIGGER CARPARAMETER_TRIGGER
  BEFORE INSERT
  ON CARPARAMETER
  FOR EACH ROW
  begin select CarParameter_id.nextval into :new.id from dual; end ;
/

