CREATE TRIGGER APPHOMEPAGE_TRI
  BEFORE INSERT
  ON APPHOMEPAGE
  FOR EACH ROW
  begin select AppHomepage_id.nextval into :new.id from dual; end;
/

