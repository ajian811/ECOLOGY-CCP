CREATE TRIGGER MODEDATASHARE_901_SET_TRI
  BEFORE INSERT
  ON MODEDATASHARE_901_SET
  FOR EACH ROW
  begin   select modeDataShare_901_set_id.nextval into :new.id from dual;   end;
/

