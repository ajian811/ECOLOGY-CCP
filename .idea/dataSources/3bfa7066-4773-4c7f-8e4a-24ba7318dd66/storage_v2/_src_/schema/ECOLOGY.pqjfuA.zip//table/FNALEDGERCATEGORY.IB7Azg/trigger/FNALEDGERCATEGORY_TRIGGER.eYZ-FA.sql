CREATE TRIGGER FNALEDGERCATEGORY_TRIGGER
  BEFORE INSERT
  ON FNALEDGERCATEGORY
  FOR EACH ROW
  begin select FnaLedgerCategory_id.nextval into :new.id from dual; end;
/

