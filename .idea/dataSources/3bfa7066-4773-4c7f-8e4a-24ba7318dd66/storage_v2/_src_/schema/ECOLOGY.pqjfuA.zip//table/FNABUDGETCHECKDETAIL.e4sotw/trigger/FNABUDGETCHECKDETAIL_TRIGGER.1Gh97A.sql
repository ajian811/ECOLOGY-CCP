CREATE TRIGGER FNABUDGETCHECKDETAIL_TRIGGER
  BEFORE INSERT
  ON FNABUDGETCHECKDETAIL
  FOR EACH ROW
  begin select FnaBudgetCheckDetail_id.nextval into :new.id from dual; end;
/

