CREATE TRIGGER BILL_HRMDISMISS_TRIGGER
  BEFORE INSERT
  ON BILL_HRMDISMISS
  FOR EACH ROW
  begin select Bill_HrmDismiss_id.nextval INTO :new.id from dual; end;
/

