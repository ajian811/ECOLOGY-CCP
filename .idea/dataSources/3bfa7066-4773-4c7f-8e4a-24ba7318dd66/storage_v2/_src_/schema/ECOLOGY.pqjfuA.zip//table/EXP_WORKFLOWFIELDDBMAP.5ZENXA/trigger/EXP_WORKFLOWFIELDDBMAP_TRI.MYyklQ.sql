CREATE TRIGGER EXP_WORKFLOWFIELDDBMAP_TRI
  BEFORE INSERT
  ON EXP_WORKFLOWFIELDDBMAP
  FOR EACH ROW
  begin select exp_workflowFieldDBMap_id.nextval into :new.id from dual; end;
/

