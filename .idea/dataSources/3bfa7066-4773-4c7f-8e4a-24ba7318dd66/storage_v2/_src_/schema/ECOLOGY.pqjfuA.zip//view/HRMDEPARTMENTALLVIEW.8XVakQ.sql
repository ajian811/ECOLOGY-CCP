CREATE VIEW HRMDEPARTMENTALLVIEW AS
  SELECT id,departmentname,departmentmark,departmentcode,supdepid,allsupdepid,canceled,subcompanyid1,showorder,tlevel,ecology_pinyin_search, 1 AS virtualtype FROM HrmDepartment UNION SELECT id,departmentname,departmentmark,departmentcode,supdepid,allsupdepid,canceled,subcompanyid1,showorder,tlevel,ecology_pinyin_search,virtualtype FROM HrmDepartmentvirtual

/

