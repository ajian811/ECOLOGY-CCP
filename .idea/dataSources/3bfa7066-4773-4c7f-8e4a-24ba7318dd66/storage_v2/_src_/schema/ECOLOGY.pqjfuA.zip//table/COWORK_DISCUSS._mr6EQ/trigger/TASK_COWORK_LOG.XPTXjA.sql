CREATE TRIGGER TASK_COWORK_LOG
  AFTER INSERT OR DELETE
  ON COWORK_DISCUSS
  FOR EACH ROW
  DECLARE var_userid integer; var_workdate CHAR(10); var_taskid integer; var_logid integer; begin if inserting then BEGIN var_userid:=:new.discussant; var_workdate:=:new.createdate; var_taskid:=:new.coworkid; var_logid:=:new.id; insert into task_operateLog(userid,workdate,tasktype,taskid,logid,createdate,createtime,logtype) VALUES(var_userid,var_workdate,5,var_taskid,var_logid,to_char(sysdate,'yyyy-mm-dd'),to_char(sysdate,'hh24:mi:ss'),1); END; end if; if deleting then var_taskid:=:old.coworkid; var_userid:=:old.discussant; DELETE FROM task_operateLog WHERE userid=var_userid AND tasktype=5 AND taskid=var_taskid; end if; end;
/

