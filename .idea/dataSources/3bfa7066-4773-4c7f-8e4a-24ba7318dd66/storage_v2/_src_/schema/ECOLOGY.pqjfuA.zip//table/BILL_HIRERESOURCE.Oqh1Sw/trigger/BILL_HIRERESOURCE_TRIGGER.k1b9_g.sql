CREATE TRIGGER BILL_HIRERESOURCE_TRIGGER
  BEFORE INSERT
  ON BILL_HIRERESOURCE
  FOR EACH ROW
  begin select bill_HireResource_id.nextval INTO :new.id from dual; end;
/

