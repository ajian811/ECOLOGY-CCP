CREATE TRIGGER COWORK_TYPES_TRIGGER
  BEFORE INSERT
  ON COWORK_TYPES
  FOR EACH ROW
  begin select cowork_types_id.nextval into :new.id from dual; end;
/

