CREATE TRIGGER BLOG_DISCUSS_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_DISCUSS
  FOR EACH ROW
  begin select blog_discuss_id.nextval into :new.id from dual; end;
/

