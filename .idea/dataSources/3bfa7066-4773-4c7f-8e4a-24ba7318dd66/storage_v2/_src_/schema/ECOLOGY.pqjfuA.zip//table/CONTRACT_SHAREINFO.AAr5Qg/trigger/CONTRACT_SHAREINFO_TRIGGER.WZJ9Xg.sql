CREATE TRIGGER CONTRACT_SHAREINFO_TRIGGER
  BEFORE INSERT
  ON CONTRACT_SHAREINFO
  FOR EACH ROW
  begin select Contract_ShareInfo_id.nextval into :new.id from dual; end;
/

