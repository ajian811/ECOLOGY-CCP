CREATE TRIGGER BILL_CPTLOSS_TRI
  BEFORE INSERT
  ON BILL_CPTLOSS
  FOR EACH ROW
  begin select bill_cptloss_id.nextval into :new.id from dual; end;
/

