CREATE TRIGGER COWORK_ITEM_LABEL_ID_TRIGGER
  BEFORE INSERT
  ON COWORK_ITEM_LABEL
  FOR EACH ROW
  begin select cowork_item_label_id.nextval into:New.id from dual; end;
/

