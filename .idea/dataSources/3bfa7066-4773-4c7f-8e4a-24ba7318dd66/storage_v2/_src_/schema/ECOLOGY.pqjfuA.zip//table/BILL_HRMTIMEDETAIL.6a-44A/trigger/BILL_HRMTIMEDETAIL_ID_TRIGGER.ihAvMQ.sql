CREATE TRIGGER BILL_HRMTIMEDETAIL_ID_TRIGGER
  BEFORE INSERT
  ON BILL_HRMTIMEDETAIL
  FOR EACH ROW
  begin select bill_hrmtimedetail_Id.nextval into :new.id from dual; end;
/

