CREATE TRIGGER ACTIONSETTING_TRI
  BEFORE INSERT
  ON ACTIONSETTING
  FOR EACH ROW
  begin select actionsetting_seq.nextval into :new.id from dual; end;
/

