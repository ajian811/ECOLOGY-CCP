CREATE TRIGGER TR_CPCOMPANYINFO
  BEFORE INSERT
  ON CPCOMPANYINFO
  FOR EACH ROW
  begin select sq_CPCOMPANYINFO.nextval into :new.companyid from dual; end;
/

