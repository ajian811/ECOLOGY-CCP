CREATE TRIGGER CRM_BUSLOG_TRIGGER
  BEFORE INSERT
  ON CRM_BUSNIESSINFOLOG
  FOR EACH ROW
  WHEN ( FOR EACH ROW )
begin select CRM_busLog_sequence.nextval into:new.id from dual; end;
/

