CREATE TRIGGER DIRACCESSCONTROLLIST_TRIGGER
  BEFORE INSERT
  ON DIRACCESSCONTROLLIST
  FOR EACH ROW
  begin select DirAccessControlList_id.nextval into :new.mainid from dual; end;
/

