CREATE TRIGGER FNABORROWINFO_TRIGGER
  BEFORE INSERT
  ON FNABORROWINFO
  FOR EACH ROW
  begin select seq_FnaBorrowInfo_id.nextval into :new.id from dual; end;
/

