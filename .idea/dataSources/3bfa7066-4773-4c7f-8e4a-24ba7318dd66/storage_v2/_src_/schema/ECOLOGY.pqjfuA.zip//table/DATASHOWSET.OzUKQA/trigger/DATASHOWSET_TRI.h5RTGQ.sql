CREATE TRIGGER DATASHOWSET_TRI
  BEFORE INSERT
  ON DATASHOWSET
  FOR EACH ROW
  begin select datashowset_seq.nextval into :new.id from dual; end;
/

