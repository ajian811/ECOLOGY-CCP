CREATE TRIGGER FNAFEETYPERULESET_TRIGGER
  BEFORE INSERT
  ON FNABUDGETFEETYPERULESET
  FOR EACH ROW
  begin select seq_FnabudgetfeetypeRuleSet_id.nextval into :new.id from dual; end;
/

