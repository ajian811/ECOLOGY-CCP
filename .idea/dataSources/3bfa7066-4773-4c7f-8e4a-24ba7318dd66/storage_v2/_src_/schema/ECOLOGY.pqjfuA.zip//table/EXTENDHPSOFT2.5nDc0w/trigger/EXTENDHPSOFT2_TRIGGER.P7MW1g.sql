CREATE TRIGGER EXTENDHPSOFT2_TRIGGER
  BEFORE INSERT
  ON EXTENDHPSOFT2
  FOR EACH ROW
  begin select extendHpSoft2_id.nextval into :new.id from dual; end;
/

