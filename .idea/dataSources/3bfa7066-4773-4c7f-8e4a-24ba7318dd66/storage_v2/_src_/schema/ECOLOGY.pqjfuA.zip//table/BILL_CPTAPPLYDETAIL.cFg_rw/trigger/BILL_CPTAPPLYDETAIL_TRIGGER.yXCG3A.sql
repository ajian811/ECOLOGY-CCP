CREATE TRIGGER BILL_CPTAPPLYDETAIL_TRIGGER
  BEFORE INSERT
  ON BILL_CPTAPPLYDETAIL
  FOR EACH ROW
  begin select bill_CptApplyDetail_id.nextval INTO :new.id from dual; end;
/

