CREATE TRIGGER EXP_LOGDETAIL_TRI
  BEFORE INSERT
  ON EXP_LOGDETAIL
  FOR EACH ROW
  begin select exp_logdetail_id.nextval into :new.id from dual; end;
/

