CREATE TRIGGER CRM_CONTACTERTITLE_TRIGGER
  BEFORE INSERT
  ON CRM_CONTACTERTITLE
  FOR EACH ROW
  begin select CRM_ContacterTitle_id.nextval into :new.id from dual; end;
/

