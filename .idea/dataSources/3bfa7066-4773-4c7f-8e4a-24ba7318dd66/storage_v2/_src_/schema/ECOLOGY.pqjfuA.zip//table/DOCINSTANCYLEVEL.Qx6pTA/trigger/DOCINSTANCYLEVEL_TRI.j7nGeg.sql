CREATE TRIGGER DOCINSTANCYLEVEL_TRI
  BEFORE INSERT
  ON DOCINSTANCYLEVEL
  FOR EACH ROW
  begin select DocInstancyLevel_id.nextval into :new.id from dual; end;
/

