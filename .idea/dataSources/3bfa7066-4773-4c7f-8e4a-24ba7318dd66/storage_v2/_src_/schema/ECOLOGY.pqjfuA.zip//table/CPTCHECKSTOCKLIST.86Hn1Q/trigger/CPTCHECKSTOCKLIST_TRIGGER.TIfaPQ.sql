CREATE TRIGGER CPTCHECKSTOCKLIST_TRIGGER
  BEFORE INSERT
  ON CPTCHECKSTOCKLIST
  FOR EACH ROW
  begin select CptCheckStockList_id.nextval into :new.id from dual; end;
/

