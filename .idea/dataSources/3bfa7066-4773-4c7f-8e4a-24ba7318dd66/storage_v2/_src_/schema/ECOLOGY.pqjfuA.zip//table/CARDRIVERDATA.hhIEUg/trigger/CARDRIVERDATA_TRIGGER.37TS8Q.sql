CREATE TRIGGER CARDRIVERDATA_TRIGGER
  BEFORE INSERT
  ON CARDRIVERDATA
  FOR EACH ROW
  begin select CarDriverData_id.nextval into :new.id from dual; end ;
/

