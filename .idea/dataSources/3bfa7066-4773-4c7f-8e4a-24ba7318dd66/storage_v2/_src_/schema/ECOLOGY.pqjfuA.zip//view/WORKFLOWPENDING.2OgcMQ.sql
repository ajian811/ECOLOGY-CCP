CREATE VIEW WORKFLOWPENDING AS
  SELECT      userid, COUNT(requestid) AS Expr1 FROM        workflow_currentoperator WHERE     (isremark IN ('0', '1', '5')) AND (islasttimes = 1) AND (usertype = 0) and exists (select 1 from hrmresource where hrmresource.id=workflow_currentoperator.userid and hrmresource.status in (0,1,2,3) ) GROUP BY userid ORDER BY COUNT(requestid) desc

/

