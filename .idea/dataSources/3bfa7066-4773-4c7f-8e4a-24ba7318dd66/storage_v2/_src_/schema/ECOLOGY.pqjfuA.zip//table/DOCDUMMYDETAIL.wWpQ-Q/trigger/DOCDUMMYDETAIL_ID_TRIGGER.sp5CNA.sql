CREATE TRIGGER DOCDUMMYDETAIL_ID_TRIGGER
  BEFORE INSERT
  ON DOCDUMMYDETAIL
  FOR EACH ROW
  begin select DocDummyDetail_Id.nextval into :new.id from dual; end ;
/

