CREATE TRIGGER MODEVIEWLOG_902_TRI
  BEFORE INSERT
  ON MODEVIEWLOG_902
  FOR EACH ROW
  begin   select ModeViewLog_902_id.nextval into :new.id from dual;   end;
/

