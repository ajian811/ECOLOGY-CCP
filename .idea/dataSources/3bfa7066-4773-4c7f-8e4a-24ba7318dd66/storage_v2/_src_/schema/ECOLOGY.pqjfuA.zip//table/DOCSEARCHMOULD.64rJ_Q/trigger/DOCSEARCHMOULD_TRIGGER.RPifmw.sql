CREATE TRIGGER DOCSEARCHMOULD_TRIGGER
  BEFORE INSERT
  ON DOCSEARCHMOULD
  FOR EACH ROW
  begin select DocSearchMould_id.nextval INTO :new.id from dual; end;
/

