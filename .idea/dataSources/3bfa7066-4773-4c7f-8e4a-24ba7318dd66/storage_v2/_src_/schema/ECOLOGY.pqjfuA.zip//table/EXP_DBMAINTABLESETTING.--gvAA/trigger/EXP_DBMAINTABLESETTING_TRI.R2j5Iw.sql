CREATE TRIGGER EXP_DBMAINTABLESETTING_TRI
  BEFORE INSERT
  ON EXP_DBMAINTABLESETTING
  FOR EACH ROW
  begin select exp_dbmaintablesetting_id.nextval into :new.id from dual; end;
/

