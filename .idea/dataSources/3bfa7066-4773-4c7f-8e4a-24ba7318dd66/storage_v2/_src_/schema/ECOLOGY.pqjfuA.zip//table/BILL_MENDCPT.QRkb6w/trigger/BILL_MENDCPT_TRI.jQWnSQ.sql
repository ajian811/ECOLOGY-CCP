CREATE TRIGGER BILL_MENDCPT_TRI
  BEFORE INSERT
  ON BILL_MENDCPT
  FOR EACH ROW
  begin select bill_mendCpt_id.nextval into :new.id from dual; end;
/

