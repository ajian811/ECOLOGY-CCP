CREATE TRIGGER BLOG_TEMPCONDITION_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_TEMPCONDITION
  FOR EACH ROW
  begin select blog_tempCondition_id.nextval into :new.id from dual; end;
/

