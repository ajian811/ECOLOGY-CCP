CREATE TRIGGER FINANCESET_TRI
  BEFORE INSERT
  ON FINANCESET
  FOR EACH ROW
  begin select financeset_seq.nextval into :new.id from dual; end;
/

