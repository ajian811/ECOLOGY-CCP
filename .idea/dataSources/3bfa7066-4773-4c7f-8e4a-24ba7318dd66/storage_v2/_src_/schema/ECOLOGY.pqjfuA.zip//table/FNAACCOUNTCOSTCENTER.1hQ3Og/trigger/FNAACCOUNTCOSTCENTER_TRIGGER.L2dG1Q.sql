CREATE TRIGGER FNAACCOUNTCOSTCENTER_TRIGGER
  BEFORE INSERT
  ON FNAACCOUNTCOSTCENTER
  FOR EACH ROW
  begin select FnaAccountCostcenter_id.nextval into :new.id from dual; end;
/

