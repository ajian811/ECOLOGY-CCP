CREATE TRIGGER DOCAPPROVEWF_TRI
  BEFORE INSERT
  ON DOCAPPROVEWF
  FOR EACH ROW
  begin select DocApproveWf_Id.nextval into :new.id from dual; end;
/

