CREATE TRIGGER SHAREMEMBERS_ID_TRIGGER
  BEFORE INSERT
  ON COTYPE_SHAREMEMBERS
  FOR EACH ROW
  begin select sharemembers_Id.nextval into :new.id from dual; end;
/

