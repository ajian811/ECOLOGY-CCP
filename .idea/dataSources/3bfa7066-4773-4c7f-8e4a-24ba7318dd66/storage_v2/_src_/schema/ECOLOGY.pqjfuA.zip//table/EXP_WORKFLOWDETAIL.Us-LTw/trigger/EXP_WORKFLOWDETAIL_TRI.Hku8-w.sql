CREATE TRIGGER EXP_WORKFLOWDETAIL_TRI
  BEFORE INSERT
  ON EXP_WORKFLOWDETAIL
  FOR EACH ROW
  begin select exp_workflowDetail_id.nextval into :new.id from dual; end;
/

