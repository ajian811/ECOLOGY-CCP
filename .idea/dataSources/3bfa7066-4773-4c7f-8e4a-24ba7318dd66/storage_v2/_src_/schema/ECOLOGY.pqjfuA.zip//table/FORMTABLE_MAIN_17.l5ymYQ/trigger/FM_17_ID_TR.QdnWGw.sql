CREATE TRIGGER FM_17_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_17
  FOR EACH ROW
  begin 
   select fm_17_ID.nextval into :new.id from dual; 
 end;
/

