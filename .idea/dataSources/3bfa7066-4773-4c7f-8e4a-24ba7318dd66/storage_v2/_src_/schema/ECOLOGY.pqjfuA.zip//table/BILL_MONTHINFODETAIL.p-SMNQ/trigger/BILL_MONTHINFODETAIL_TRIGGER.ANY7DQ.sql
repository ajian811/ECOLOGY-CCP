CREATE TRIGGER BILL_MONTHINFODETAIL_TRIGGER
  BEFORE INSERT
  ON BILL_MONTHINFODETAIL
  FOR EACH ROW
  begin select bill_monthinfodetail_id.nextval INTO :new.id from dual; end;
/

