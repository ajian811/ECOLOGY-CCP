CREATE TRIGGER BILL_EXPENSEDETAIL_TRI
  BEFORE INSERT
  ON BILL_EXPENSEDETAIL
  FOR EACH ROW
  begin select Bill_ExpenseDetail_id.nextval into :new.id from dual; end;
/

