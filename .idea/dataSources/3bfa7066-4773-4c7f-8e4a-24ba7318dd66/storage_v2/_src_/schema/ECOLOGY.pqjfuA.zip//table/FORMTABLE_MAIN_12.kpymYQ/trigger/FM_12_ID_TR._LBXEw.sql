CREATE TRIGGER FM_12_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_12
  FOR EACH ROW
  begin 
   select fm_12_ID.nextval into :new.id from dual; 
 end;
/

