CREATE TRIGGER FNAACCOUNTLOG_TRIGGER
  BEFORE INSERT
  ON FNAACCOUNTLOG
  FOR EACH ROW
  begin select FnaAccountLog_id.nextval into :new.id from dual; end ;
/

