CREATE TRIGGER FNAACCOUNTDEPARTMENT_TRIGGER
  BEFORE INSERT
  ON FNAACCOUNTDEPARTMENT
  FOR EACH ROW
  begin select FnaAccountDepartment_id.nextval into :new.id from dual; end;
/

