CREATE TRIGGER FM_17_DT1_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_17_DT1
  FOR EACH ROW
  begin    select fm_17_DT1_ID.nextval into :new.id from dual;  end;
/

