CREATE TRIGGER BLOG_ATTENTION_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_ATTENTION
  FOR EACH ROW
  begin select blog_attention_id.nextval into :new.id from dual; end;
/

