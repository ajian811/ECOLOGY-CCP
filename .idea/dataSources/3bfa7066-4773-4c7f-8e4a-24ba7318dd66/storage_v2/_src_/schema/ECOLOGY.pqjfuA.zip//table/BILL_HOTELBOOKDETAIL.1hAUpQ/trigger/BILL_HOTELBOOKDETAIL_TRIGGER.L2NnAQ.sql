CREATE TRIGGER BILL_HOTELBOOKDETAIL_TRIGGER
  BEFORE INSERT
  ON BILL_HOTELBOOKDETAIL
  FOR EACH ROW
  begin select bill_HotelBookDetail_id.nextval INTO :new.id from dual; end;
/

