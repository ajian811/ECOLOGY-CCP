CREATE VIEW WFEX_VIEW AS
  select id,name,workflowid,datasourceid,subcompanyid, 0 as type,status from wfec_outdatawfset union all select id,name ,workflowid,datasourceid,subcompanyid,1 as type,status from wfec_indatawfset

/

