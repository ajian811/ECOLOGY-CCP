CREATE TRIGGER FNAEXPENSEFEETYPE_TRIGGER
  BEFORE INSERT
  ON FNAEXPENSEFEETYPE
  FOR EACH ROW
  begin select FnaExpensefeeType_id.nextval into :new.id from dual; end;
/

