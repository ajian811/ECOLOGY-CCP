CREATE TRIGGER FNAAINFOLOG_TRIGGER
  BEFORE INSERT
  ON FNAADVANCEINFOAMOUNTLOG
  FOR EACH ROW
  begin select seq_FnaAInfoLog_id.nextval into :new.id from dual; end;
/

