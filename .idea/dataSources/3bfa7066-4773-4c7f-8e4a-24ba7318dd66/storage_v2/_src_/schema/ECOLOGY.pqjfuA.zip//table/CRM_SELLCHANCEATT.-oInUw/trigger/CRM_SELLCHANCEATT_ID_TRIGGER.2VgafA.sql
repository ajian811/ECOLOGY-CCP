CREATE TRIGGER CRM_SELLCHANCEATT_ID_TRIGGER
  BEFORE INSERT
  ON CRM_SELLCHANCEATT
  FOR EACH ROW
  begin select CRM_SellchanceAtt_id.nextval into :new.id from dual; end;
/

