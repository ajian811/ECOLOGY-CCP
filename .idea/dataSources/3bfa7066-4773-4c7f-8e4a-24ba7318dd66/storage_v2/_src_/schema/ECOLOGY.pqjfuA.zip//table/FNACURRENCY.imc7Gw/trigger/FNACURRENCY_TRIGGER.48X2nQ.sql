CREATE TRIGGER FNACURRENCY_TRIGGER
  BEFORE INSERT
  ON FNACURRENCY
  FOR EACH ROW
  begin select FnaCurrency_id.nextval INTO :new.id from dual; end;
/

