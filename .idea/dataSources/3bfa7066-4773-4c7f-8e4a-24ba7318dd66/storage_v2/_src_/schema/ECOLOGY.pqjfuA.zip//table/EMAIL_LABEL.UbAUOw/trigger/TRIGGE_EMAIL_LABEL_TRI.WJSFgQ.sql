CREATE TRIGGER TRIGGE_EMAIL_LABEL_TRI
  BEFORE INSERT
  ON EMAIL_LABEL
  FOR EACH ROW
  begin select email_label_id.nextval into :new.id from dual; end;
/

