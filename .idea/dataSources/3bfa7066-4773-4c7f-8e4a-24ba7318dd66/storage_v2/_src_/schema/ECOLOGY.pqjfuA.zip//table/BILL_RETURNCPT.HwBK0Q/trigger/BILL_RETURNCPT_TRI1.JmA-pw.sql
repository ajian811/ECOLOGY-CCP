CREATE TRIGGER BILL_RETURNCPT_TRI1
  BEFORE INSERT
  ON BILL_RETURNCPT
  FOR EACH ROW
  begin select bill_returncpt_id.nextval into :new.id from dual; end;
/

