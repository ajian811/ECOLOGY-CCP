CREATE TRIGGER FM_16_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_16
  FOR EACH ROW
  begin 
   select fm_16_ID.nextval into :new.id from dual; 
 end;
/

