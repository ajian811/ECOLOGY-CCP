CREATE TRIGGER BLOG_ZAN_ID_TRI
  BEFORE INSERT
  ON BLOG_ZAN
  FOR EACH ROW
  begin select blog_zan_id.nextval into :new.id from dual; end;
/

