CREATE TRIGGER APPFIELDUI_TRI
  BEFORE INSERT
  ON APPFIELDUI
  FOR EACH ROW
  begin select AppFieldUI_id.nextval into :new.id from dual; end;
/

