CREATE TRIGGER DOCPREVIEWHISTORY_ID_TRIGGER
  BEFORE INSERT
  ON DOCPREVIEWHISTORY
  FOR EACH ROW
  begin select DocPreviewHistory_id.nextval into :new.id from dual; end;
/

