CREATE TRIGGER DOCSECCATEGORYMOULD_TRIGGER
  BEFORE INSERT
  ON DOCSECCATEGORYMOULD
  FOR EACH ROW
  begin select DocSecCategoryMould_Id.nextval into :new.id from dual; end;
/

