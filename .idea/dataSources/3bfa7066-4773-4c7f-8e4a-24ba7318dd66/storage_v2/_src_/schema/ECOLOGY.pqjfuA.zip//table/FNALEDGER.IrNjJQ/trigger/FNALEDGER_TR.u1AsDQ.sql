CREATE TRIGGER FNALEDGER_TR
  BEFORE INSERT
  ON FNALEDGER
  FOR EACH ROW
  begin select FnaLedger_id.nextval into :new.id from dual; end;
/

