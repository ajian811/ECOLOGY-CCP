CREATE TRIGGER CUSTOMFIELDSHOWCHANGE_TRI
  BEFORE INSERT
  ON CUSTOMFIELDSHOWCHANGE
  FOR EACH ROW
  begin select customfieldshowchange_id.nextval into :new.id from dual; end;
/

