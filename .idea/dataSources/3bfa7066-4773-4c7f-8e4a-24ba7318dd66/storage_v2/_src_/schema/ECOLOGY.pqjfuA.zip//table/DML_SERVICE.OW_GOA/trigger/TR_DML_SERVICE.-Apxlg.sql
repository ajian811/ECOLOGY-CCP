CREATE TRIGGER TR_DML_SERVICE
  BEFORE INSERT
  ON DML_SERVICE
  FOR EACH ROW
  begin select sq_dml_service.nextval into :new.id from dual; end;
/

