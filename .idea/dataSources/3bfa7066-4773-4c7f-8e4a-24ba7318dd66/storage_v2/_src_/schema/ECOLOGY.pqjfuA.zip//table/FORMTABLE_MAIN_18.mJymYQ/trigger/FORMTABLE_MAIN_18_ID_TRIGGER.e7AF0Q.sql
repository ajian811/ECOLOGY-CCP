CREATE TRIGGER FORMTABLE_MAIN_18_ID_TRIGGER
  BEFORE INSERT
  ON FORMTABLE_MAIN_18
  FOR EACH ROW
  begin select formtable_main_18_Id.nextval into :new.id from dual; end;
/

