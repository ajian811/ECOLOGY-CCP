CREATE TRIGGER EXP_DBDETAIL_TRI
  BEFORE INSERT
  ON EXP_DBDETAIL
  FOR EACH ROW
  begin select exp_dbdetail_id.nextval into :new.id from dual; end;
/

