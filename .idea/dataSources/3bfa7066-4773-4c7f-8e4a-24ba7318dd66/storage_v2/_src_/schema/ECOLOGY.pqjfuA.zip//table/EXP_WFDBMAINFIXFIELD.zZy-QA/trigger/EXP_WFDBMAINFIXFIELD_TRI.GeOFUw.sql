CREATE TRIGGER EXP_WFDBMAINFIXFIELD_TRI
  BEFORE INSERT
  ON EXP_WFDBMAINFIXFIELD
  FOR EACH ROW
  begin select exp_wfDBMainFixField_id.nextval into :new.id from dual; end;
/

