CREATE TRIGGER BILL_HRMTRAINPLAN_TRI
  BEFORE INSERT
  ON BILL_HRMTRAINPLAN
  FOR EACH ROW
  begin select Bill_HrmTrainplan_id.nextval INTO :new.id from dual; end;
/

