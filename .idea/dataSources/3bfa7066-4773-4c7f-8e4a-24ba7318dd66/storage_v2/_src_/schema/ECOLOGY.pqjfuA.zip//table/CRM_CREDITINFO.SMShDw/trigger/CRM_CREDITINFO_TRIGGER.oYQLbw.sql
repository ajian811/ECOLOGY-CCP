CREATE TRIGGER CRM_CREDITINFO_TRIGGER
  BEFORE INSERT
  ON CRM_CREDITINFO
  FOR EACH ROW
  begin select CRM_CreditInfo_id.nextval into :new.id from dual; end;
/

