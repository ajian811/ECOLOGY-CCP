CREATE TRIGGER CPTCAPITALPARTS_TRIGGER
  BEFORE INSERT
  ON CPTCAPITALPARTS
  FOR EACH ROW
  begin select cptcapitalparts_id.nextval into :new.id from dual; end;
/

