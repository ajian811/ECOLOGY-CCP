CREATE TRIGGER CRM_CUSTOMERDEFINFIELD_ID_TRI
  BEFORE INSERT
  ON CRM_CUSTOMERDEFINFIELD
  FOR EACH ROW
  begin select CRM_CustomerDefinField_id.nextval into :new.id from dual; end;
/

