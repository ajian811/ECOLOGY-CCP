CREATE TRIGGER DOCSENDDOCKIND_TRI
  BEFORE INSERT
  ON DOCSENDDOCKIND
  FOR EACH ROW
  begin select DocSendDocKind_id.nextval into :new.id from dual; end;
/

