CREATE TRIGGER BILL_CPTADJUSTDETAIL_TRIGGER
  BEFORE INSERT
  ON BILL_CPTADJUSTDETAIL
  FOR EACH ROW
  begin select bill_CptAdjustDetail_id.nextval INTO :new.id from dual; end;
/

