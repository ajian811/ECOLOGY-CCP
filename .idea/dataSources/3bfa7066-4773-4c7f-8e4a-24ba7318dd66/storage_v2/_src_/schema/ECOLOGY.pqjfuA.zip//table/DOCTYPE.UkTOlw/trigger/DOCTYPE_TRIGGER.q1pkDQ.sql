CREATE TRIGGER DOCTYPE_TRIGGER
  BEFORE INSERT
  ON DOCTYPE
  FOR EACH ROW
  begin select DocType_id.nextval INTO :new.id from dual; end;
/

