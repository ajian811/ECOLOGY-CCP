CREATE TRIGGER COWORKQUITER_TRIGGER
  BEFORE INSERT
  ON COWORK_QUITER
  FOR EACH ROW
  begin select cowork_quiter_seq.nextval into:new.id from sys.dual; end;
/

