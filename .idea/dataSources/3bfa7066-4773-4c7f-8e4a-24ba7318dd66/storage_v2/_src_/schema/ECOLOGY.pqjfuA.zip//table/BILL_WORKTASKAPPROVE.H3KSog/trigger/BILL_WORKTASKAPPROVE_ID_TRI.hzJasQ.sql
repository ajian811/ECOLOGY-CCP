CREATE TRIGGER BILL_WORKTASKAPPROVE_ID_TRI
  BEFORE INSERT
  ON BILL_WORKTASKAPPROVE
  FOR EACH ROW
  begin select bill_worktaskapprove_id.nextval into :new.id from dual; end;
/

