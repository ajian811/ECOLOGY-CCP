CREATE TRIGGER FORMTABLE_MAIN_28_ID_TRIGGER
  BEFORE INSERT
  ON FORMTABLE_MAIN_28
  FOR EACH ROW
  begin select formtable_main_28_Id.nextval into :new.id from dual; end;
/

