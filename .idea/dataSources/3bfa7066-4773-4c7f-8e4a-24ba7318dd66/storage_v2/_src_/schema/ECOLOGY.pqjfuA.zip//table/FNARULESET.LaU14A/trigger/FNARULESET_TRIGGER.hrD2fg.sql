CREATE TRIGGER FNARULESET_TRIGGER
  BEFORE INSERT
  ON FNARULESET
  FOR EACH ROW
  begin select seq_fnaRuleSet_id.nextval into :new.id from dual; end;
/

