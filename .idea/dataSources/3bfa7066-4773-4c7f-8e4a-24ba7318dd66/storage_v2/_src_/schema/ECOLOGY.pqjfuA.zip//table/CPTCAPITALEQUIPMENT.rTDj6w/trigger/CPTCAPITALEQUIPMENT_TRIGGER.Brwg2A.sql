CREATE TRIGGER CPTCAPITALEQUIPMENT_TRIGGER
  BEFORE INSERT
  ON CPTCAPITALEQUIPMENT
  FOR EACH ROW
  begin select cptcapitalequipment_id.nextval into :new.id from dual; end;
/

