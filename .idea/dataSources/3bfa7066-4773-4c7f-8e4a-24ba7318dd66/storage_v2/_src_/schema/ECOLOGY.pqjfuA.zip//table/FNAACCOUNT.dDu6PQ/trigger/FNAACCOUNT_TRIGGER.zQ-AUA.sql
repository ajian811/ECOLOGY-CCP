CREATE TRIGGER FNAACCOUNT_TRIGGER
  BEFORE INSERT
  ON FNAACCOUNT
  FOR EACH ROW
  begin select FnaAccount_id.nextval into :new.id from dual; end;
/

