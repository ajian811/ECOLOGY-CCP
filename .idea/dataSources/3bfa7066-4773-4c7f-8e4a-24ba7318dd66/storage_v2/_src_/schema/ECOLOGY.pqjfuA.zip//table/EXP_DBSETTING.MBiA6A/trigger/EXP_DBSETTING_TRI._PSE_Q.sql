CREATE TRIGGER EXP_DBSETTING_TRI
  BEFORE INSERT
  ON EXP_DBSETTING
  FOR EACH ROW
  begin select exp_dbsetting_id.nextval into :new.id from dual; end;
/

