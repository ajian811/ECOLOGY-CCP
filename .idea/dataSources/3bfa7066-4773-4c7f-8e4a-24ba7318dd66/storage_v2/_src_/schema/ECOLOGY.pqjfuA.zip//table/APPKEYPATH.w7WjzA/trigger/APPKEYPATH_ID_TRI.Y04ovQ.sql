CREATE TRIGGER APPKEYPATH_ID_TRI
  BEFORE INSERT
  ON APPKEYPATH
  FOR EACH ROW
  begin select AppKeyPath_id.nextval into :new.id from dual; end;
/

