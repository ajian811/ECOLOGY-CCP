CREATE TRIGGER CRM_SHAREINFO_TRIGGER
  BEFORE INSERT
  ON CRM_SHAREINFO
  FOR EACH ROW
  begin select CRM_ShareInfo_id.nextval into :new.id from dual; end;
/

