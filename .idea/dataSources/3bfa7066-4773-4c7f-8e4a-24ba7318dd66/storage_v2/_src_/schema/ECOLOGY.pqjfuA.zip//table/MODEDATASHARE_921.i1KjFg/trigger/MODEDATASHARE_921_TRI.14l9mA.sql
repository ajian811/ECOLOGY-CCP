CREATE TRIGGER MODEDATASHARE_921_TRI
  BEFORE INSERT
  ON MODEDATASHARE_921
  FOR EACH ROW
  begin   select modeDataShare_921_id.nextval into :new.id from dual;   end;
/

