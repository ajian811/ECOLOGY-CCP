CREATE TRIGGER COWORK_IMPORTANT_ID_TRIGGER
  BEFORE INSERT
  ON COWORK_IMPORTANT
  FOR EACH ROW
  begin select cowork_important_id.nextval into:New.id from dual; end;
/

