CREATE TRIGGER DOCMOULD_TRIGGER
  BEFORE INSERT
  ON DOCMOULD
  FOR EACH ROW
  begin select DocMould_id.nextval INTO :new.id from dual; end;
/

