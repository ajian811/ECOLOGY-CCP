CREATE TRIGGER BILL_MEETING_DT2_SERVICE_TR
  BEFORE INSERT
  ON BILL_MEETING_DT2_SERVICE
  FOR EACH ROW
  begin select Bill_Meeting_dt2_Service_ID.nextval into :new.id from dual; end;
/

