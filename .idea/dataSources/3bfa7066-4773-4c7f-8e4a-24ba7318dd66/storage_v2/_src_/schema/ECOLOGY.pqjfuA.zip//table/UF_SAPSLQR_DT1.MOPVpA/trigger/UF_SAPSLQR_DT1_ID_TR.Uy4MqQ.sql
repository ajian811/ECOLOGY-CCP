CREATE TRIGGER UF_SAPSLQR_DT1_ID_TR
  BEFORE INSERT
  ON UF_SAPSLQR_DT1
  FOR EACH ROW
  begin select uf_sapslqr_dt1_Id.nextval into :new.id from dual; end;
/

