CREATE TRIGGER EXP_SETTING_TRI
  BEFORE INSERT
  ON EXP_SETTING
  FOR EACH ROW
  begin select exp_setting_id.nextval into :new.id from dual; end;
/

