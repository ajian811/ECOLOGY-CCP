CREATE TRIGGER FNABUDGETINFOPAGESIZE_TRIGGER
  BEFORE INSERT
  ON FNABUDGETINFOPAGESIZE
  FOR EACH ROW
  begin select seq_FnaBudgetInfoPageSize_id.nextval into :new.id from dual; end;
/

