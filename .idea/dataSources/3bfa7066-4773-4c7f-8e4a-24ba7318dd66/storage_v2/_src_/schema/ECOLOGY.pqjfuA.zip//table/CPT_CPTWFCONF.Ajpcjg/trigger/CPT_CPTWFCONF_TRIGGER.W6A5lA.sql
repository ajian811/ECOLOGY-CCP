CREATE TRIGGER CPT_CPTWFCONF_TRIGGER
  BEFORE INSERT
  ON CPT_CPTWFCONF
  FOR EACH ROW
  begin select cpt_cptwfconf_ID.nextval into :new.id from dual; end;
/

