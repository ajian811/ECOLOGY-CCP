CREATE TRIGGER BBPMAPPGOAL_TRIGGER
  BEFORE INSERT
  ON BILLBPMAPPROVEGOAL
  FOR EACH ROW
  begin select BBPMAppGoal_id.nextval into :new.id from dual; end;
/

