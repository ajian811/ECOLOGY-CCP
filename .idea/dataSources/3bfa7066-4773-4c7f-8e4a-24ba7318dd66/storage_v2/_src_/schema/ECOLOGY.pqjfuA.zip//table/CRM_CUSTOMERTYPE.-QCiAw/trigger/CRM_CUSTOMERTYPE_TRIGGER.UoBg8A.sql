CREATE TRIGGER CRM_CUSTOMERTYPE_TRIGGER
  BEFORE INSERT
  ON CRM_CUSTOMERTYPE
  FOR EACH ROW
  begin select CRM_CustomerType_id.nextval into :new.id from dual; end;
/

