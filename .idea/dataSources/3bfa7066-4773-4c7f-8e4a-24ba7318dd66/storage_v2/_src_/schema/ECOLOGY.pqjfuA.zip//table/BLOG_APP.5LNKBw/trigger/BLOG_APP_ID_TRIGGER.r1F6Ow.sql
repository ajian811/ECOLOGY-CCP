CREATE TRIGGER BLOG_APP_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_APP
  FOR EACH ROW
  begin select blog_app_id.nextval into :new.id from dual; end;
/

