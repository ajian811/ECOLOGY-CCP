CREATE TRIGGER DOCPRINTLOG_TRI
  BEFORE INSERT
  ON DOCPRINTLOG
  FOR EACH ROW
  begin select DocPrintLog_id.nextval into :new.id from dual; end;
/

