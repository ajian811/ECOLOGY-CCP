CREATE TRIGGER DOCFRONTPAGE_TRIGGER
  BEFORE INSERT
  ON DOCFRONTPAGE
  FOR EACH ROW
  begin select DocFrontpage_id.nextval into:new.id from dual; end;
/

