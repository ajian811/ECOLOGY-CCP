CREATE TRIGGER CPTCODE_TRIGGER
  BEFORE INSERT
  ON CPTCODE
  FOR EACH ROW
  begin select cptcode_id.nextval into :new.id from dual; end;
/

