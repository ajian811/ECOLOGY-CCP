CREATE TRIGGER CPTCAPITAL_TRIGGER
  BEFORE INSERT
  ON CPTCAPITAL
  FOR EACH ROW
  begin select CptCapital_id.nextval INTO :new.id from dual; end;
/

