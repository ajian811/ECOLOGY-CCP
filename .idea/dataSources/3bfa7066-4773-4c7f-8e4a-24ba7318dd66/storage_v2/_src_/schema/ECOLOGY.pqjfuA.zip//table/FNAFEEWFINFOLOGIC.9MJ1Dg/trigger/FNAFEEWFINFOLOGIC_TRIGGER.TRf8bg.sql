CREATE TRIGGER FNAFEEWFINFOLOGIC_TRIGGER
  BEFORE INSERT
  ON FNAFEEWFINFOLOGIC
  FOR EACH ROW
  begin select seq_fnaFeeWfInfoLogic_id.nextval into :new.id from dual; end;
/

