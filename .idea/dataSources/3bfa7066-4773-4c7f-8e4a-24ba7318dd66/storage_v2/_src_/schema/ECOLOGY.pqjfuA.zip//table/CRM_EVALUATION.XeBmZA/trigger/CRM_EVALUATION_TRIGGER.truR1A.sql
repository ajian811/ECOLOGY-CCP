CREATE TRIGGER CRM_EVALUATION_TRIGGER
  BEFORE INSERT
  ON CRM_EVALUATION
  FOR EACH ROW
  begin select CRM_Evaluation_id.nextval into :new.id from dual; end;
/

