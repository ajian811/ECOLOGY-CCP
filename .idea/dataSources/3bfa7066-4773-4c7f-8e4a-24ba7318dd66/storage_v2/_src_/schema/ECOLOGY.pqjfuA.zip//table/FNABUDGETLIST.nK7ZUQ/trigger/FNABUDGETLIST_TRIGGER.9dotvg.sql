CREATE TRIGGER FNABUDGETLIST_TRIGGER
  BEFORE INSERT
  ON FNABUDGETLIST
  FOR EACH ROW
  begin select FnaBudgetList_id.nextval into :new.id from dual; end;
/

