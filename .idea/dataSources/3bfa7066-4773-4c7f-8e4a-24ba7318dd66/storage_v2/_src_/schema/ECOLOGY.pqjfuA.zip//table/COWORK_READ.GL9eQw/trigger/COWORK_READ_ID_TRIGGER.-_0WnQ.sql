CREATE TRIGGER COWORK_READ_ID_TRIGGER
  BEFORE INSERT
  ON COWORK_READ
  FOR EACH ROW
  begin select cowork_read_id.nextval into:New.id from dual; end;
/

