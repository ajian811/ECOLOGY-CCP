CREATE TRIGGER FNALOANLOG_TRIGGER
  BEFORE INSERT
  ON FNALOANLOG
  FOR EACH ROW
  begin select FnaLoanLog_id.nextval into :new.id from dual; end ;
/

