CREATE TRIGGER FORMENGINESET_ID_TRI
  BEFORE INSERT
  ON FORMENGINESET
  FOR EACH ROW
  begin select formEngineSet_id.nextval into :new.id from dual; end;
/

