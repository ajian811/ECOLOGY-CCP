CREATE TRIGGER FORMTABLE_MAIN_29_ID_TRIGGER
  BEFORE INSERT
  ON FORMTABLE_MAIN_29
  FOR EACH ROW
  begin select formtable_main_29_Id.nextval into :new.id from dual; end;
/

