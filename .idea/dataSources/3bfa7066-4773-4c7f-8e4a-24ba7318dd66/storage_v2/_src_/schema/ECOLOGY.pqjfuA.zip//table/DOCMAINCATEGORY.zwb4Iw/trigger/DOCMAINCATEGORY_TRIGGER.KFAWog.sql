CREATE TRIGGER DOCMAINCATEGORY_TRIGGER
  BEFORE INSERT
  ON DOCMAINCATEGORY
  FOR EACH ROW
  begin select DocMainCategory_id.nextval into:new.id from dual; end;
/

