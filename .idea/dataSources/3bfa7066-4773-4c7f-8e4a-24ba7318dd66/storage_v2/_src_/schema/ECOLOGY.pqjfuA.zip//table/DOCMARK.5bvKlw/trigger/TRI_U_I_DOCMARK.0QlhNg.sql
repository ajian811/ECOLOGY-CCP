CREATE TRIGGER TRI_U_I_DOCMARK
  AFTER INSERT OR UPDATE
  ON DOCMARK
  FOR EACH ROW
  Declare id_1 integer; docid_2 integer; markold_3 integer; marknew_4 integer;  begin id_1 := :old.id; markold_3 := :old.mark; docid_2 := :new.docid; marknew_4 := :new.mark; if (id_1 is null) /*insert*/ then update docdetail set countmark = nvl(countmark,0)+1,summark = nvl(summark,0)+marknew_4 where id=docid_2; else update docdetail set summark = summark-markold_3+marknew_4 where  id =docid_2; end if; end;
/

