CREATE TRIGGER MODEDATASHARE_55_SET_TRI
  BEFORE INSERT
  ON MODEDATASHARE_55_SET
  FOR EACH ROW
  begin   select modeDataShare_55_set_id.nextval into :new.id from dual;   end;
/

