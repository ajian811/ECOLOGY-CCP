CREATE TRIGGER CRM_SELLTIMESPAN_TRIGGER
  BEFORE INSERT
  ON CRM_SELLTIMESPAN
  FOR EACH ROW
  begin select CRM_SelltimeSpan_id.nextval INTO :new.id from dual; end;
/

