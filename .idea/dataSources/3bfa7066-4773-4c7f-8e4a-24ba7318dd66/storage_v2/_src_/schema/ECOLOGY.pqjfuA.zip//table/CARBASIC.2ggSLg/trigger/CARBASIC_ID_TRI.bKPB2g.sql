CREATE TRIGGER CARBASIC_ID_TRI
  BEFORE INSERT
  ON CARBASIC
  FOR EACH ROW
  begin select carbasic_id.nextval into :new.id from dual; end;
/

