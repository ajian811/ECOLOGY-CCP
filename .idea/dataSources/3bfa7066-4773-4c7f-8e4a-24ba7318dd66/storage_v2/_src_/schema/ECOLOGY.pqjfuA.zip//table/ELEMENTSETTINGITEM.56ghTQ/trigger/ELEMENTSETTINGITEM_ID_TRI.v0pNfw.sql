CREATE TRIGGER ELEMENTSETTINGITEM_ID_TRI
  BEFORE INSERT
  ON ELEMENTSETTINGITEM
  FOR EACH ROW
  begin select elementsettingitem_id.nextval into :new.id from dual; end;
/

