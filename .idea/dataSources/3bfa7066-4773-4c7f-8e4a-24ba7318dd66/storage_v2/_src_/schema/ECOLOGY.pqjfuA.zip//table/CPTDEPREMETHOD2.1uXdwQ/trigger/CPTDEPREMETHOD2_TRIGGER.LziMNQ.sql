CREATE TRIGGER CPTDEPREMETHOD2_TRIGGER
  BEFORE INSERT
  ON CPTDEPREMETHOD2
  FOR EACH ROW
  begin select CptDepreMethod2_id.nextval into :new.id from dual; end;
/

