CREATE TRIGGER FNARULESETDTL_TRIGGER
  BEFORE INSERT
  ON FNARULESETDTL
  FOR EACH ROW
  begin select seq_fnaRuleSetDtl_id.nextval into :new.id from dual; end;
/

