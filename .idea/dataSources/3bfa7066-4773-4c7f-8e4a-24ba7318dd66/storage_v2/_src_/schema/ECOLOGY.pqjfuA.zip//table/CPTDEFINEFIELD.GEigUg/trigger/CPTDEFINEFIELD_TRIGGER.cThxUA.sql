CREATE TRIGGER CPTDEFINEFIELD_TRIGGER
  BEFORE INSERT
  ON CPTDEFINEFIELD
  FOR EACH ROW
  begin select cptDefineField_ID.nextval into :new.id from dual; end;
/

