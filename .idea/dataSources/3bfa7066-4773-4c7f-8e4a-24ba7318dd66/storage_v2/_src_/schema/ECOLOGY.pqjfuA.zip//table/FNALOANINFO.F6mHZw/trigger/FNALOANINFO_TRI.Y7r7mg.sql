CREATE TRIGGER FNALOANINFO_TRI
  BEFORE INSERT
  ON FNALOANINFO
  FOR EACH ROW
  begin select FnaLoanInfo_id.nextval into :new.id from dual; end;
/

