CREATE TRIGGER DATASHOWPARAM_TRI
  BEFORE INSERT
  ON DATASHOWPARAM
  FOR EACH ROW
  begin select datashowparam_seq.nextval into :new.id from dual; end;
/

