CREATE TRIGGER BILL_HRMRESOURCEABSENSE_TRI
  BEFORE INSERT
  ON BILL_HRMRESOURCEABSENSE
  FOR EACH ROW
  begin select Bill_HrmResourceAbsense_id.nextval into :new.id from dual; end;
/

