CREATE TRIGGER CRM_CONTRACTPROINFO_TRIGGER
  BEFORE INSERT
  ON CRM_CONTRACTPROINFO
  FOR EACH ROW
  begin select CRM_ContractProInfo_id.nextval into :new.id from dual; end;
/

