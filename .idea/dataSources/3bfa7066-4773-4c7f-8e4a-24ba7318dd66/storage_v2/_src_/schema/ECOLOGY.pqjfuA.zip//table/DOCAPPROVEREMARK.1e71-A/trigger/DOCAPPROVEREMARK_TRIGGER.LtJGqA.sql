CREATE TRIGGER DOCAPPROVEREMARK_TRIGGER
  BEFORE INSERT
  ON DOCAPPROVEREMARK
  FOR EACH ROW
  begin select DocApproveRemark_id.nextval into :new.id from dual; end;
/

