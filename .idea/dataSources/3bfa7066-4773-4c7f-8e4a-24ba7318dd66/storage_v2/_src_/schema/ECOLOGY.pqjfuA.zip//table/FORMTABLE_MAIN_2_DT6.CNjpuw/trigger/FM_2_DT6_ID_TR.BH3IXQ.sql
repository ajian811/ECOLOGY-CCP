CREATE TRIGGER FM_2_DT6_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_2_DT6
  FOR EACH ROW
  begin    select fm_2_DT6_ID.nextval into :new.id from dual;  end;
/

