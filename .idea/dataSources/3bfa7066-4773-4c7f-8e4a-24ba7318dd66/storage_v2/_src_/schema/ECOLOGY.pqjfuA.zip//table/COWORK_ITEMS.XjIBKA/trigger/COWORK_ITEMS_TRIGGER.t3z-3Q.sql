CREATE TRIGGER COWORK_ITEMS_TRIGGER
  BEFORE INSERT
  ON COWORK_ITEMS
  FOR EACH ROW
  begin select cowork_items_id.nextval into :new.id from dual; end;
/

