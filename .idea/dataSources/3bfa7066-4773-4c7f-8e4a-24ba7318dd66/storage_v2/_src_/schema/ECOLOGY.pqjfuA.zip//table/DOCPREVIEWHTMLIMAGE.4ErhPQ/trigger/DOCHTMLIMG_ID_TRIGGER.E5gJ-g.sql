CREATE TRIGGER DOCHTMLIMG_ID_TRIGGER
  BEFORE INSERT
  ON DOCPREVIEWHTMLIMAGE
  FOR EACH ROW
  begin select DocHtmlImg_id.nextval into :new.id from dual; end;
/

