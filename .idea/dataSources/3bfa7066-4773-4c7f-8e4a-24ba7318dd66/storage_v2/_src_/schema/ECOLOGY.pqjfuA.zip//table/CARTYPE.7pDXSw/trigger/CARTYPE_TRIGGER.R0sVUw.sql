CREATE TRIGGER CARTYPE_TRIGGER
  BEFORE INSERT
  ON CARTYPE
  FOR EACH ROW
  begin select CarType_id.nextval into :new.id from dual; end;
/

