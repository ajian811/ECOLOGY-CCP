CREATE TRIGGER DMLACTIONFIELDMAP_TRI
  BEFORE INSERT
  ON DMLACTIONFIELDMAP
  FOR EACH ROW
  begin select dmlactionfieldmap_seq.nextval into :new.id from dual; end;
/

