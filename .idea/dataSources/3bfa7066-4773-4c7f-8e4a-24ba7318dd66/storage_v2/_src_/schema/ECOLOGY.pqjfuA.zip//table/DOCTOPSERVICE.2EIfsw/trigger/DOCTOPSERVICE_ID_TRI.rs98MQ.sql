CREATE TRIGGER DOCTOPSERVICE_ID_TRI
  BEFORE INSERT
  ON DOCTOPSERVICE
  FOR EACH ROW
  begin select DocTopService_id.nextval into :new.id from dual; end;
/

