CREATE TRIGGER MODEDATASHARE_901_TRI
  BEFORE INSERT
  ON MODEDATASHARE_901
  FOR EACH ROW
  begin   select modeDataShare_901_id.nextval into :new.id from dual;   end;
/

