CREATE TRIGGER CRM_CONTACTER_GETPINYIN
  BEFORE INSERT OR UPDATE OF FULLNAME
  ON CRM_CUSTOMERCONTACTER
  FOR EACH ROW
  begin select Lower(getpinyin((:new.fullname))) into :new.ecology_pinyin_search from dual; end;
/

