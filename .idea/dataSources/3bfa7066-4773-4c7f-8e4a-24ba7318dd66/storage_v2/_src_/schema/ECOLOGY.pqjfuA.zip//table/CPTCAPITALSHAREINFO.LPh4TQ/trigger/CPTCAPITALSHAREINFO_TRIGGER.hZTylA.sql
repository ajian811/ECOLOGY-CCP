CREATE TRIGGER CPTCAPITALSHAREINFO_TRIGGER
  BEFORE INSERT
  ON CPTCAPITALSHAREINFO
  FOR EACH ROW
  begin select CptCapitalShareInfo_id.nextval into :new.id from dual; end;
/

