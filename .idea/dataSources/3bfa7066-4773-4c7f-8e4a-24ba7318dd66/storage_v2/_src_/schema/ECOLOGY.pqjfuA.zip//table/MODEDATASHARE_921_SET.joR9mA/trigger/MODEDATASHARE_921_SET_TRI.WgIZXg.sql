CREATE TRIGGER MODEDATASHARE_921_SET_TRI
  BEFORE INSERT
  ON MODEDATASHARE_921_SET
  FOR EACH ROW
  begin   select modeDataShare_921_set_id.nextval into :new.id from dual;   end;
/

