CREATE TRIGGER MODEVIEWLOG_921_TRI
  BEFORE INSERT
  ON MODEVIEWLOG_921
  FOR EACH ROW
  begin   select ModeViewLog_921_id.nextval into :new.id from dual;   end;
/

