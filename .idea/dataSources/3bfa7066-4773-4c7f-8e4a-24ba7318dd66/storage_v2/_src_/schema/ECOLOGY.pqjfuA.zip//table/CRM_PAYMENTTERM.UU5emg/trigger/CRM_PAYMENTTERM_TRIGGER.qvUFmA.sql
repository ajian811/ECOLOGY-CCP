CREATE TRIGGER CRM_PAYMENTTERM_TRIGGER
  BEFORE INSERT
  ON CRM_PAYMENTTERM
  FOR EACH ROW
  begin select CRM_PaymentTerm_id.nextval into :new.id from dual; end;
/

