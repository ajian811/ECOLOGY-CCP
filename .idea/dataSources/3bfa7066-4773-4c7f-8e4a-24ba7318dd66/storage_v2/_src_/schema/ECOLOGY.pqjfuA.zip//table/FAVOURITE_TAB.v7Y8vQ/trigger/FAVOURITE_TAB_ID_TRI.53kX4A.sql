CREATE TRIGGER FAVOURITE_TAB_ID_TRI
  BEFORE INSERT
  ON FAVOURITE_TAB
  FOR EACH ROW
  begin select favourite_tab_id.nextval into :new.id from dual; end;
/

