CREATE TRIGGER BILL_WEEKINFODETAIL_TRIGGER
  BEFORE INSERT
  ON BILL_WEEKINFODETAIL
  FOR EACH ROW
  begin select bill_weekinfodetail_id.nextval INTO :new.id from dual; end;
/

