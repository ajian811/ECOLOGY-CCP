CREATE TRIGGER FNAFEEWFINFOLOGICR_TRIGGER
  BEFORE INSERT
  ON FNAFEEWFINFOLOGICREVERSE
  FOR EACH ROW
  begin select seq_fnaFeeWfInfoLogicR_id.nextval into :new.id from dual; end;
/

