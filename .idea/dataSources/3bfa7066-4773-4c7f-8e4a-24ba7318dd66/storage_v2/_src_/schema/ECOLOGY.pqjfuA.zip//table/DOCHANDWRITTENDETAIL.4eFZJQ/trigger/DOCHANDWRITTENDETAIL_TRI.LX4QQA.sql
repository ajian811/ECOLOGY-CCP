CREATE TRIGGER DOCHANDWRITTENDETAIL_TRI
  BEFORE INSERT
  ON DOCHANDWRITTENDETAIL
  FOR EACH ROW
  begin select DocHandwrittenDetail_id.nextval into :new.id from dual; end;
/

