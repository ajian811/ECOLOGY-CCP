CREATE TRIGGER DOCSECCATEGORYIMPORT_TRIGGER
  BEFORE INSERT
  ON DOCSECCATEGORYIMPORTHISTORY
  FOR EACH ROW
  begin select docseccategoryimporthistory_id.nextval INTO :new.id from dual; end;
/

