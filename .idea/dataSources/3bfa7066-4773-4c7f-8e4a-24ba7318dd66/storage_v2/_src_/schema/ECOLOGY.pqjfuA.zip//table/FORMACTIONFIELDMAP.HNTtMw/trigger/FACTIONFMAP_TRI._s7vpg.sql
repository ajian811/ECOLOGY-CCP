CREATE TRIGGER FACTIONFMAP_TRI
  BEFORE INSERT
  ON FORMACTIONFIELDMAP
  FOR EACH ROW
  begin select factionfmap_seq.nextval into :new.id from dual; end;
/

