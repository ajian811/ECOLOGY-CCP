CREATE TRIGGER CPTSTOCKINDETAIL_TRIGGER
  BEFORE INSERT
  ON CPTSTOCKINDETAIL
  FOR EACH ROW
  begin select CptStockInDetail_id.nextval into :new.id from dual; end;
/

