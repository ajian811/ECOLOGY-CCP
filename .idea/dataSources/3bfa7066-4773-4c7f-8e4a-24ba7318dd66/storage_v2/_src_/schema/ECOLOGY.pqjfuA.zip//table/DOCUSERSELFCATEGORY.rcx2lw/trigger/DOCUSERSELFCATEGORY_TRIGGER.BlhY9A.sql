CREATE TRIGGER DOCUSERSELFCATEGORY_TRIGGER
  BEFORE INSERT
  ON DOCUSERSELFCATEGORY
  FOR EACH ROW
  begin select DocUserselfCategory_id.nextval into :new.id from dual; end;
/

