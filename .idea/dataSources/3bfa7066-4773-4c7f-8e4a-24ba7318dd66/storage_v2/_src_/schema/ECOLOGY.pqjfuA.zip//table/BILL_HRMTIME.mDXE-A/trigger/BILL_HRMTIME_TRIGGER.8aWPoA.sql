CREATE TRIGGER BILL_HRMTIME_TRIGGER
  BEFORE INSERT
  ON BILL_HRMTIME
  FOR EACH ROW
  begin select bill_HrmTime_id.nextval INTO :new.id from dual; end;
/

