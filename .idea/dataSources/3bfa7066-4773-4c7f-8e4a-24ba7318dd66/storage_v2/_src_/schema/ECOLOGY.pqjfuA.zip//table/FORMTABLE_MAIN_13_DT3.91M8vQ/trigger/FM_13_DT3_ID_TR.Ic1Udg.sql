CREATE TRIGGER FM_13_DT3_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_13_DT3
  FOR EACH ROW
  begin    select fm_13_DT3_ID.nextval into :new.id from dual;  end;
/

