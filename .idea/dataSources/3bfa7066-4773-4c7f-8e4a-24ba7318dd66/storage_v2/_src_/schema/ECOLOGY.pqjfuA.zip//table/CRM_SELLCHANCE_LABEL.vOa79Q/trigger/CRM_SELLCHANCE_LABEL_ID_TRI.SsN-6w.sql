CREATE TRIGGER CRM_SELLCHANCE_LABEL_ID_TRI
  BEFORE INSERT
  ON CRM_SELLCHANCE_LABEL
  FOR EACH ROW
  begin select CRM_Sellchance_label_id.nextval into :new.id from dual; end;
/

