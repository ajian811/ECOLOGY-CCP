CREATE TRIGGER BLOG_SPECIFIEDSHARE_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_SPECIFIEDSHARE
  FOR EACH ROW
  begin select blog_specifiedShare_id.nextval into :new.id from dual; end;
/

