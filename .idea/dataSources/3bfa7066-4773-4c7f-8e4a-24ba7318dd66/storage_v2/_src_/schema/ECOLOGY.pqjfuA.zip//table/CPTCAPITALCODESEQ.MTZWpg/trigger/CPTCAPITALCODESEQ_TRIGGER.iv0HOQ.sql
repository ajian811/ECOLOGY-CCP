CREATE TRIGGER CPTCAPITALCODESEQ_TRIGGER
  BEFORE INSERT
  ON CPTCAPITALCODESEQ
  FOR EACH ROW
  begin select cptcapitalcodeseq_id.nextval into :new.id from dual; end;
/

