CREATE TRIGGER BILL_BOHAILEAVE_TRIGGER
  BEFORE INSERT
  ON BILL_BOHAILEAVE
  FOR EACH ROW
  begin select Bill_BoHaiLeave_id.nextval into :new.id from dual; end;
/

