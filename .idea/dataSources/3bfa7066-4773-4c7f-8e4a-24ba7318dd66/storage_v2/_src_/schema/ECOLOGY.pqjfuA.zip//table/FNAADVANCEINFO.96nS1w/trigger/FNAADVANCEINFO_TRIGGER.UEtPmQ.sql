CREATE TRIGGER FNAADVANCEINFO_TRIGGER
  BEFORE INSERT
  ON FNAADVANCEINFO
  FOR EACH ROW
  begin select seq_FnaAdvanceInfo_id.nextval into :new.id from dual; end;
/

