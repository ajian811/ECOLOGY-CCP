CREATE TRIGGER FNABUDGETINFO_TRIGGER
  BEFORE INSERT
  ON FNABUDGETINFO
  FOR EACH ROW
  begin select FnaBudgetInfo_id.nextval INTO :new.id from dual; end;
/

