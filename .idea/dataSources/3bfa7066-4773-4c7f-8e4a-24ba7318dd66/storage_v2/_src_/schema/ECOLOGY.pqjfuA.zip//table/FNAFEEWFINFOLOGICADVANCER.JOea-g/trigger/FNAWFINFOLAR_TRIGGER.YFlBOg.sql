CREATE TRIGGER FNAWFINFOLAR_TRIGGER
  BEFORE INSERT
  ON FNAFEEWFINFOLOGICADVANCER
  FOR EACH ROW
  begin select seq_fnaWfInfoLAR_id.nextval into :new.id from dual; end;
/

