CREATE TRIGGER CRM_SELLCHANCELABEL_ID_TRIGGER
  BEFORE INSERT
  ON CRM_SELLCHANCELABEL
  FOR EACH ROW
  begin select CRM_SellchanceLabel_id.nextval into :new.id from dual; end;
/

