CREATE TRIGGER BILL_FNABUDGET_TRIGGER
  BEFORE INSERT
  ON BILL_FNABUDGET
  FOR EACH ROW
  begin select bill_FnaBudget_id.nextval into :new.id from dual; end;
/

