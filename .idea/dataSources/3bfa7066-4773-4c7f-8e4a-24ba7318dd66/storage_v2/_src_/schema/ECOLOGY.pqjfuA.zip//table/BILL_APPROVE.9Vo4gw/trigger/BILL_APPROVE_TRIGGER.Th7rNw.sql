CREATE TRIGGER BILL_APPROVE_TRIGGER
  BEFORE INSERT
  ON BILL_APPROVE
  FOR EACH ROW
  begin select bill_Approve_id.nextval INTO :new.id from dual; end;
/

