CREATE TRIGGER FNABUDGETDETAIL_TRIGGER
  BEFORE INSERT
  ON FNABUDGETDETAIL
  FOR EACH ROW
  begin select FnaBudgetDetail_id.nextval into :new.id from dual; end;
/

