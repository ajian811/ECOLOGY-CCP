CREATE TRIGGER FNABUDGETFEETYPEFCC_TRIGGER
  BEFORE INSERT
  ON FNABUDGETFEETYPEFCC
  FOR EACH ROW
  begin select seq_fnabudgetfeetypeFcc_id.nextval into :new.id from dual; end;
/

