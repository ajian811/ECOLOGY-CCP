CREATE TRIGGER CPTUSELOG_TRIGGER
  BEFORE INSERT
  ON CPTUSELOG
  FOR EACH ROW
  begin select CptUseLog_id.nextval into :new.id from dual; end;
/

