CREATE TRIGGER FORMMODEELEMENT_TRIGGER
  BEFORE INSERT
  ON FORMMODEELEMENT
  FOR EACH ROW
  begin select formmodeelement_ID.nextval into :new.id from dual; end;
/

