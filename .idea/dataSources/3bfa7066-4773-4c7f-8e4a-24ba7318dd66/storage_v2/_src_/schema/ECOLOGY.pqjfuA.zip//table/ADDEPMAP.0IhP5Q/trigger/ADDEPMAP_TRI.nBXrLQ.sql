CREATE TRIGGER ADDEPMAP_TRI
  BEFORE INSERT
  ON ADDEPMAP
  FOR EACH ROW
  begin select addepmap_seq.nextval into :new.id from dual; end;
/

