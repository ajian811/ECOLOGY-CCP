CREATE TRIGGER BILL_ITEMUSAGE_TRIGGER
  BEFORE INSERT
  ON BILL_ITEMUSAGE
  FOR EACH ROW
  begin select bill_itemusage_id.nextval INTO :new.id from dual; end;
/

