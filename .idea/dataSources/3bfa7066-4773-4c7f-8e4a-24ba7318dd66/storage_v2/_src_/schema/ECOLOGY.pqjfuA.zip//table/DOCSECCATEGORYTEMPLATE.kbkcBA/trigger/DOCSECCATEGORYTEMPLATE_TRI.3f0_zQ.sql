CREATE TRIGGER DOCSECCATEGORYTEMPLATE_TRI
  BEFORE INSERT
  ON DOCSECCATEGORYTEMPLATE
  FOR EACH ROW
  begin select DocSecCategoryTemplate_Id.nextval into :new.id from dual; end;
/

