CREATE TRIGGER FNATRANSACTION_TRIGGER
  BEFORE INSERT
  ON FNATRANSACTION
  FOR EACH ROW
  begin select FnaTransaction_id.nextval into :new.id from dual; end;
/

