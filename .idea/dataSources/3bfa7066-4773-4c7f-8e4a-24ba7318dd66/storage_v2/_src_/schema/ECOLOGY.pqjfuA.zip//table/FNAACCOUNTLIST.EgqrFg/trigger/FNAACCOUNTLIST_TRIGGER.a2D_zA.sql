CREATE TRIGGER FNAACCOUNTLIST_TRIGGER
  BEFORE INSERT
  ON FNAACCOUNTLIST
  FOR EACH ROW
  begin select FnaAccountList_id.nextval into :new.id from dual; end;
/

