CREATE TRIGGER COMMUNICATELOG_ID_TRI
  BEFORE INSERT
  ON COMMUNICATELOG
  FOR EACH ROW
  begin select CommunicateLog_id.nextval into :new.id from dual; end;
/

