CREATE TRIGGER BILL_CPTFETCHDETAIL_TRIGGER
  BEFORE INSERT
  ON BILL_CPTFETCHDETAIL
  FOR EACH ROW
  begin select bill_CptFetchDetail_id.nextval INTO :new.id from dual; end;
/

