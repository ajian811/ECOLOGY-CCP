CREATE TRIGGER DMLACTIONSQLSET_TRI
  BEFORE INSERT
  ON DMLACTIONSQLSET
  FOR EACH ROW
  begin select dmlactionsqlset_seq.nextval into :new.id from dual; end;
/

