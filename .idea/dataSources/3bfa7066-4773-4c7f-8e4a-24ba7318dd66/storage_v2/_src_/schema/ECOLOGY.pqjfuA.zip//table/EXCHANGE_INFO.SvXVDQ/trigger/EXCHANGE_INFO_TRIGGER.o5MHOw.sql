CREATE TRIGGER EXCHANGE_INFO_TRIGGER
  BEFORE INSERT
  ON EXCHANGE_INFO
  FOR EACH ROW
  begin select Exchange_Info_id.nextval INTO :new.id from dual; end;
/

