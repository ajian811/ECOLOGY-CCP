CREATE TRIGGER CRM_SUCCESSFACTOR_TRIGGER
  BEFORE INSERT
  ON CRM_SUCCESSFACTOR
  FOR EACH ROW
  begin select CRM_Successfactor_id.nextval INTO :new.id from dual; end;
/

