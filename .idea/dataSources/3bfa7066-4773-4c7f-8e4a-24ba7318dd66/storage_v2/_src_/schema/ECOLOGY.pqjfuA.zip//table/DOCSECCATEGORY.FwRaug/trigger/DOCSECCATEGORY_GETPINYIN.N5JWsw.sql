CREATE TRIGGER DOCSECCATEGORY_GETPINYIN
  BEFORE INSERT OR UPDATE OF CATEGORYNAME
  ON DOCSECCATEGORY
  FOR EACH ROW
  begin select Lower(getpinyin((:new.categoryname))) into :new.ecology_pinyin_search from dual; end;
/

