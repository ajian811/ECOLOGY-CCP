CREATE TRIGGER FM_13_DT4_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_13_DT4
  FOR EACH ROW
  begin    select fm_13_DT4_ID.nextval into :new.id from dual;  end;
/

