CREATE TRIGGER BILL_CPTAPPLYMAIN_TRIGGER
  BEFORE INSERT
  ON BILL_CPTAPPLYMAIN
  FOR EACH ROW
  begin select bill_CptApplyMain_id.nextval INTO :new.id from dual; end;
/

