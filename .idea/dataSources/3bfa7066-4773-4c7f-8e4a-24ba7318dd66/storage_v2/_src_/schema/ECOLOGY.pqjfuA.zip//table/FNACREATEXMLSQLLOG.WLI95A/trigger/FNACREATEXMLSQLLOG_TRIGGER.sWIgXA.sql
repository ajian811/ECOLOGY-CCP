CREATE TRIGGER FNACREATEXMLSQLLOG_TRIGGER
  BEFORE INSERT
  ON FNACREATEXMLSQLLOG
  FOR EACH ROW
  begin select seq_FnaCreateXmlSqlLog_id.nextval into :new.id from dual; end;
/

