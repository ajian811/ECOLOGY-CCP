CREATE TRIGGER FNARULESETDTL1_TRIGGER
  BEFORE INSERT
  ON FNARULESETDTL1
  FOR EACH ROW
  begin select seq_fnaRuleSetDtl1_id.nextval into :new.id from dual; end;
/

