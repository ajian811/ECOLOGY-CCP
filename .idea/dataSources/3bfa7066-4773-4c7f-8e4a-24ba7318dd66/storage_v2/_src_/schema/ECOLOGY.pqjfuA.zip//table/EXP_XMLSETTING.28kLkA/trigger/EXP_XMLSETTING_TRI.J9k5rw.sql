CREATE TRIGGER EXP_XMLSETTING_TRI
  BEFORE INSERT
  ON EXP_XMLSETTING
  FOR EACH ROW
  begin select exp_xmlsetting_id.nextval into :new.id from dual; end;
/

