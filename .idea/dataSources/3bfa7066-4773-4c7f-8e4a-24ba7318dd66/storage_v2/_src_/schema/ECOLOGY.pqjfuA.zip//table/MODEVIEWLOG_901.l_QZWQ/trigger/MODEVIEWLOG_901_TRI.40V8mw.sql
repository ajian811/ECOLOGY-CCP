CREATE TRIGGER MODEVIEWLOG_901_TRI
  BEFORE INSERT
  ON MODEVIEWLOG_901
  FOR EACH ROW
  begin   select ModeViewLog_901_id.nextval into :new.id from dual;   end;
/

