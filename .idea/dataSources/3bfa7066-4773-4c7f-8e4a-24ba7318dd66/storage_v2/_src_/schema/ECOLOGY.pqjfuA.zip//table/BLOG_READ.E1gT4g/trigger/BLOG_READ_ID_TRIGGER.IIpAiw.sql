CREATE TRIGGER BLOG_READ_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_READ
  FOR EACH ROW
  begin select blog_read_id.nextval into :new.id from dual; end;
/

