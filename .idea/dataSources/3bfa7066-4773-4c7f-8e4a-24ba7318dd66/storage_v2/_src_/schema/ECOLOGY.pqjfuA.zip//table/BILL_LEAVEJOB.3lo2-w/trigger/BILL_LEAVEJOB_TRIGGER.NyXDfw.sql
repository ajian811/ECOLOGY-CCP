CREATE TRIGGER BILL_LEAVEJOB_TRIGGER
  BEFORE INSERT
  ON BILL_LEAVEJOB
  FOR EACH ROW
  begin select bill_LeaveJob_id.nextval INTO :new.id from dual; end;
/

