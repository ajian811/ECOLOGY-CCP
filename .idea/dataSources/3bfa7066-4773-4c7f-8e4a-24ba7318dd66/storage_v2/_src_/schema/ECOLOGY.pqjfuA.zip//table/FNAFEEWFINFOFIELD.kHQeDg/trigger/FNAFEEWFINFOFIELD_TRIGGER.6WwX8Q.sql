CREATE TRIGGER FNAFEEWFINFOFIELD_TRIGGER
  BEFORE INSERT
  ON FNAFEEWFINFOFIELD
  FOR EACH ROW
  begin select seq_fnaFeeWfInfoField_id.nextval into :new.id from dual; end;
/

