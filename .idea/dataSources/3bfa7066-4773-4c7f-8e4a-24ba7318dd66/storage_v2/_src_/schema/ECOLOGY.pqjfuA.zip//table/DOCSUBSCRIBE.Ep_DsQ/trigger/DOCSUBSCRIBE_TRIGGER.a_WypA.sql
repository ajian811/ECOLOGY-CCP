CREATE TRIGGER DOCSUBSCRIBE_TRIGGER
  BEFORE INSERT
  ON DOCSUBSCRIBE
  FOR EACH ROW
  begin select DocSubscribe_id.nextval into :new.id from dual; end;
/

