CREATE TRIGGER BILL_FWAPPLY_TRIGGER
  BEFORE INSERT
  ON BILL_FNAWIPEAPPLY
  FOR EACH ROW
  begin select Bill_FnaWipeApply_id.nextval into :new.id from dual; end;
/

