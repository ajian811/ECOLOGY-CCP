CREATE TRIGGER BILL_DOCPRINTAPPLY_TRI
  BEFORE INSERT
  ON BILL_DOCPRINTAPPLY
  FOR EACH ROW
  begin select Bill_DocPrintApply_id.nextval into :new.id from dual; end;
/

