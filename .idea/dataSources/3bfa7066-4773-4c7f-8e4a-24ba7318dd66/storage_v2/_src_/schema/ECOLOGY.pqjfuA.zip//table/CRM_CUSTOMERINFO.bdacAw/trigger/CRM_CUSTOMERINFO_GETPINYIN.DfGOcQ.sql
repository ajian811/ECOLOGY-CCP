CREATE TRIGGER CRM_CUSTOMERINFO_GETPINYIN
  BEFORE INSERT OR UPDATE OF NAME
  ON CRM_CUSTOMERINFO
  FOR EACH ROW
  begin select Lower(getpinyin((:new.name))) into :new.ecology_pinyin_search from dual; end;
/

