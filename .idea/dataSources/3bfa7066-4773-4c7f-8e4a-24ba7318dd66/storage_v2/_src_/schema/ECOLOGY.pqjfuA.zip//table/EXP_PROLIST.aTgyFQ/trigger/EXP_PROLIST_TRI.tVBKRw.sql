CREATE TRIGGER EXP_PROLIST_TRI
  BEFORE INSERT
  ON EXP_PROLIST
  FOR EACH ROW
  begin select exp_ProList_id.nextval into :new.id from dual; end;
/

