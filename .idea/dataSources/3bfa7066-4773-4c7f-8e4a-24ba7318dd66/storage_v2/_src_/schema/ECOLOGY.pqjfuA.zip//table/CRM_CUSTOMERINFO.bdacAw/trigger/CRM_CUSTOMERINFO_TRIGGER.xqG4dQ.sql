CREATE TRIGGER CRM_CUSTOMERINFO_TRIGGER
  BEFORE INSERT
  ON CRM_CUSTOMERINFO
  FOR EACH ROW
  begin select CRM_CustomerInfo_id.nextval into :new.id from dual; end;
/

