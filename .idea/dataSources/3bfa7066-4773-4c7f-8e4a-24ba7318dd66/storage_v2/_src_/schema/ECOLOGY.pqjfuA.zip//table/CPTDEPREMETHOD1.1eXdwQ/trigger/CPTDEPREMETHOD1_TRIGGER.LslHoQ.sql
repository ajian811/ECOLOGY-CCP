CREATE TRIGGER CPTDEPREMETHOD1_TRIGGER
  BEFORE INSERT
  ON CPTDEPREMETHOD1
  FOR EACH ROW
  begin select CptDepreMethod1_id.nextval into :new.id from dual; end;
/

