CREATE TRIGGER CRM_FAILFACTOR_TRIGGER
  BEFORE INSERT
  ON CRM_FAILFACTOR
  FOR EACH ROW
  begin select CRM_Failfactor_id.nextval INTO :new.id from dual; end;
/

