CREATE TRIGGER BLOG_SETTING_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_SETTING
  FOR EACH ROW
  begin select blog_setting_id.nextval into :new.id from dual; end;
/

