CREATE TRIGGER BILL_HRMSCHEDULEOVERTIME_TRI
  BEFORE INSERT
  ON BILL_HRMSCHEDULEOVERTIME
  FOR EACH ROW
  begin select Bill_HrmScheduleOvertime_id.nextval INTO :new.id from dual; end;
/

