CREATE TRIGGER EXPANDBASERIGHTINFO_TRI
  BEFORE INSERT
  ON EXPANDBASERIGHTINFO
  FOR EACH ROW
  begin select expandBaseRightInfo_ID.nextval into :new.id from dual; end;
/

