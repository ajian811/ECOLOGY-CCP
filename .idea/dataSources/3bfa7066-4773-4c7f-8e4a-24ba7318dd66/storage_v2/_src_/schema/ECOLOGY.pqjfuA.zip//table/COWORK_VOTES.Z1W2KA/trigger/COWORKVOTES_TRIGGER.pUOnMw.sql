CREATE TRIGGER COWORKVOTES_TRIGGER
  BEFORE INSERT
  ON COWORK_VOTES
  FOR EACH ROW
  begin select coworkvotes_seq.nextval into:new.id from sys.dual; end;
/

