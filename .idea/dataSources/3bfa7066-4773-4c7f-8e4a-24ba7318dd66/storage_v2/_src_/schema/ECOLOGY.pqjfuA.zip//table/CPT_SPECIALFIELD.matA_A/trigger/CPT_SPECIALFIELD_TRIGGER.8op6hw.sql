CREATE TRIGGER CPT_SPECIALFIELD_TRIGGER
  BEFORE INSERT
  ON CPT_SPECIALFIELD
  FOR EACH ROW
  begin select cpt_specialfield_ID.nextval into :new.id from dual; end;
/

