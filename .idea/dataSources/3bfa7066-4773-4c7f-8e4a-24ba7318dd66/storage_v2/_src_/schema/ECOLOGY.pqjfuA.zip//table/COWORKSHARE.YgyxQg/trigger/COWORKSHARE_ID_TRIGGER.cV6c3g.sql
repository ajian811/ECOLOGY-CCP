CREATE TRIGGER COWORKSHARE_ID_TRIGGER
  BEFORE INSERT
  ON COWORKSHARE
  FOR EACH ROW
  begin select coworkshare_id.nextval into :new.id from dual; end ;
/

