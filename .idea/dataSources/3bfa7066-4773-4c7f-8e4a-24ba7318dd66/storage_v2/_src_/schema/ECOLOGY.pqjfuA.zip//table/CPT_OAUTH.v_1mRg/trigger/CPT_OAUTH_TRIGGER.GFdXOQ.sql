CREATE TRIGGER CPT_OAUTH_TRIGGER
  BEFORE INSERT
  ON CPT_OAUTH
  FOR EACH ROW
  begin select cpt_oauth_ID.nextval into :new.id from dual; end;
/

