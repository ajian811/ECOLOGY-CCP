CREATE TRIGGER EXTENDHPWEB1_ID_TRIGGER
  BEFORE INSERT
  ON EXTENDHPWEB1
  FOR EACH ROW
  begin select extendHpWeb1_Id.nextval into :new.id from dual; end ;
/

