CREATE TRIGGER DOCPICUPLOAD_TRIGGER
  BEFORE INSERT
  ON DOCPICUPLOAD
  FOR EACH ROW
  begin select DocPicUpload_id.nextval INTO :new.id from dual; end;
/

