CREATE TRIGGER BLOG_SHARE_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_SHARE
  FOR EACH ROW
  begin select blog_share_id.nextval into :new.id from dual; end;
/

