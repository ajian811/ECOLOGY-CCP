CREATE TRIGGER FNAFEEWFINFONODECTRL_TRIGGER
  BEFORE INSERT
  ON FNAFEEWFINFONODECTRL
  FOR EACH ROW
  begin select seq_fnaFeeWfInfoNodeCtrl_ID.nextval into :new.id from dual; end;
/

