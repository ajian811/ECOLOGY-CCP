CREATE TRIGGER COWORK_REMIND_ID_TRIGGER
  BEFORE INSERT
  ON COWORK_REMIND
  FOR EACH ROW
  begin select cowork_remind_id.nextval into :new.id from dual; end;
/

