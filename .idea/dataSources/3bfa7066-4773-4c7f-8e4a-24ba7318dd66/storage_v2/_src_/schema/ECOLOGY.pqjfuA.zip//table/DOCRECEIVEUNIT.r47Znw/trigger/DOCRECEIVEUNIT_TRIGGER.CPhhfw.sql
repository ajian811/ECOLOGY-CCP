CREATE TRIGGER DOCRECEIVEUNIT_TRIGGER
  BEFORE INSERT
  ON DOCRECEIVEUNIT
  FOR EACH ROW
  begin select DocReceiveUnit_Id.nextval into :new.id from dual; end;
/

