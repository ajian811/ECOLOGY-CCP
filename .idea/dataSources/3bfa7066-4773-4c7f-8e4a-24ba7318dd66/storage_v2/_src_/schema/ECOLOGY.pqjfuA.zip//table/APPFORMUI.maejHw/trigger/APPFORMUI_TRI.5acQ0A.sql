CREATE TRIGGER APPFORMUI_TRI
  BEFORE INSERT
  ON APPFORMUI
  FOR EACH ROW
  begin select AppFormUI_id.nextval into :new.id from dual; end;
/

