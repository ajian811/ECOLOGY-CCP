CREATE TRIGGER CPTCAPITAL_GETPINYIN
  BEFORE INSERT OR UPDATE OF NAME
  ON CPTCAPITAL
  FOR EACH ROW
  begin select Lower(getpinyin((:new.name))) into :new.ecology_pinyin_search from dual; end;
/

