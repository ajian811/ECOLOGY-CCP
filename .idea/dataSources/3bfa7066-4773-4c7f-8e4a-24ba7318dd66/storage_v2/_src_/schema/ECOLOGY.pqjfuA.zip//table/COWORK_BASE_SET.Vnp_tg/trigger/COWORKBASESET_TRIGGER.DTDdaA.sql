CREATE TRIGGER COWORKBASESET_TRIGGER
  BEFORE INSERT
  ON COWORK_BASE_SET
  FOR EACH ROW
  begin select coworkbaseset_seq.nextval into:new.id from sys.dual; end;
/

