CREATE TRIGGER CPTCHECKSTOCK_TRIGGER
  BEFORE INSERT
  ON CPTCHECKSTOCK
  FOR EACH ROW
  begin select CptCheckStock_id.nextval into :new.id from dual; end;
/

