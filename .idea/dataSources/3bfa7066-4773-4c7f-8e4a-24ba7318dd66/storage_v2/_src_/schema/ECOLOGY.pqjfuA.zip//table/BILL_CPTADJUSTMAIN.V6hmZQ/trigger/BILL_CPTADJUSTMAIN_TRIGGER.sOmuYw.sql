CREATE TRIGGER BILL_CPTADJUSTMAIN_TRIGGER
  BEFORE INSERT
  ON BILL_CPTADJUSTMAIN
  FOR EACH ROW
  begin select bill_CptAdjustMain_id.nextval INTO :new.id from dual; end;
/

