CREATE TRIGGER DOCREADTAG_TRIGGER
  BEFORE INSERT
  ON DOCREADTAG
  FOR EACH ROW
  begin select docReadTag_id.nextval INTO :new.id from dual; end;
/

