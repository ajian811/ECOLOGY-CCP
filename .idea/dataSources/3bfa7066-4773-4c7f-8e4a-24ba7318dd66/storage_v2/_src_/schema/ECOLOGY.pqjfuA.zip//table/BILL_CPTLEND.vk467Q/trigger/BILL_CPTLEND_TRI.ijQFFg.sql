CREATE TRIGGER BILL_CPTLEND_TRI
  BEFORE INSERT
  ON BILL_CPTLEND
  FOR EACH ROW
  begin select bill_cptlend_id.nextval into :new.id from dual; end;
/

