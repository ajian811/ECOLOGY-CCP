CREATE TRIGGER FAVOURITE_ID_TRI
  BEFORE INSERT
  ON FAVOURITE
  FOR EACH ROW
  begin select favourite_id.nextval into :new.id from dual; end;
/

