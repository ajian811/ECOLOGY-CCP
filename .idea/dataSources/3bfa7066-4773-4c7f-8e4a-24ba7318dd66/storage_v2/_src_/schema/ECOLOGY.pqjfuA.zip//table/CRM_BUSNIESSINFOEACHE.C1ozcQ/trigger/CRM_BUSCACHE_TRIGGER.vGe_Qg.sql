CREATE TRIGGER CRM_BUSCACHE_TRIGGER
  BEFORE INSERT
  ON CRM_BUSNIESSINFOEACHE
  FOR EACH ROW
  WHEN ( FOR EACH ROW )
begin select CRM_busCache_sequence.nextval into:new.id from dual; end;
/

