CREATE TRIGGER DOCSECRETLEVEL_TRI
  BEFORE INSERT
  ON DOCSECRETLEVEL
  FOR EACH ROW
  begin select DocSecretLevel_id.nextval into :new.id from dual; end;
/

