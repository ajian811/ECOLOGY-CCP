CREATE TRIGGER BLOG_NOTES_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_NOTES
  FOR EACH ROW
  begin select blog_notes_id.nextval into :new.id from dual; end;
/

