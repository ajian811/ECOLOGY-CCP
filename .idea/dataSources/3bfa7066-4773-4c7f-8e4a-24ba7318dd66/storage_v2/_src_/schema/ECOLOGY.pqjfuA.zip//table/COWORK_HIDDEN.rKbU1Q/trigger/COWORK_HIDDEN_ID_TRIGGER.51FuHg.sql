CREATE TRIGGER COWORK_HIDDEN_ID_TRIGGER
  BEFORE INSERT
  ON COWORK_HIDDEN
  FOR EACH ROW
  begin select cowork_hidden_id.nextval into:New.id from dual; end;
/

