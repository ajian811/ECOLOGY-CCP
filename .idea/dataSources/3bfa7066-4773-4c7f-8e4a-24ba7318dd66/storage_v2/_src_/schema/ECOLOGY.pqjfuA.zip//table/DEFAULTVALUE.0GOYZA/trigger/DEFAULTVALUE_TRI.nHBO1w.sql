CREATE TRIGGER DEFAULTVALUE_TRI
  BEFORE INSERT
  ON DEFAULTVALUE
  FOR EACH ROW
  begin select DefaultValue_id.nextval into :new.id from dual; end;
/

