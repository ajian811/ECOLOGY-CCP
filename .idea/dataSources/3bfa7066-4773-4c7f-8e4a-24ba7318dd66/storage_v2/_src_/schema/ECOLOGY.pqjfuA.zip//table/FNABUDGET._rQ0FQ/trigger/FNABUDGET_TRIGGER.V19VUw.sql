CREATE TRIGGER FNABUDGET_TRIGGER
  BEFORE INSERT
  ON FNABUDGET
  FOR EACH ROW
  begin select FnaBudget_id.nextval into :new.id from dual; end;
/

