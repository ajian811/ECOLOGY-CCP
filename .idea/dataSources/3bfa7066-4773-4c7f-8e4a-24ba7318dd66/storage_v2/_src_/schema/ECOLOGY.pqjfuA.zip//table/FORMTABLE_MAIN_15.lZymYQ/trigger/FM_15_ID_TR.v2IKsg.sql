CREATE TRIGGER FM_15_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_15
  FOR EACH ROW
  begin 
   select fm_15_ID.nextval into :new.id from dual; 
 end;
/

