CREATE TRIGGER CRM_GROUP_ID_TRIGGER
  BEFORE INSERT
  ON CRM_CUSTOMERDEFINFIELDGROUP
  FOR EACH ROW
  begin select CRM_CustomerDefinFieldGroup_id.nextval into :new.id from dual; end;
/

