CREATE TRIGGER FM_2_DT1_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_2_DT1
  FOR EACH ROW
  begin    select fm_2_DT1_ID.nextval into :new.id from dual;  end;
/

