CREATE TRIGGER CPT_SELECTITEM_TRIGGER
  BEFORE INSERT
  ON CPT_SELECTITEM
  FOR EACH ROW
  begin select cpt_SelectItem_ID.nextval into :new.id from dual; end;
/

