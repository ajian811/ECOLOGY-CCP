CREATE TRIGGER DOC_REPLY_TRIGGER
  BEFORE INSERT
  ON DOC_REPLY
  FOR EACH ROW
  begin select DOC_REPLY_SEQ.nextval into :new.id from dual; end ;
/

