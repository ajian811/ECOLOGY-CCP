CREATE TRIGGER TRI_UHRMPGOAL_BYSTATUS
  AFTER INSERT OR UPDATE
  ON BPMGOALGROUP
  FOR EACH ROW
  Declare status_1 char(1); groupid_2 integer; countdelete_3 integer; countinsert_4 integer;  begin countdelete_3 := :old.id; countinsert_4 :=:new.id;  /*插入时 countinsert_4 >0 AND countdelete_3 = 0 */ /*删除时 countinsert_4 =0 */ /*更新时 countinsert_4 >0 AND countdelete_3 > 0 */  /*插入*/ IF (countinsert_4>0 AND countdelete_3=0) then groupid_2 := :new.id; status_1 := :new.status; UPDATE HrmPerformanceGoal SET status=status_1 WHERE groupid=groupid_2; end if;  /*更新*/ IF (countinsert_4 >0 AND countdelete_3>0) then groupid_2 := :new.id; status_1 := :new.status; UPDATE HrmPerformanceGoal SET status=status_1 WHERE groupid=groupid_2; end if; end ;
/

