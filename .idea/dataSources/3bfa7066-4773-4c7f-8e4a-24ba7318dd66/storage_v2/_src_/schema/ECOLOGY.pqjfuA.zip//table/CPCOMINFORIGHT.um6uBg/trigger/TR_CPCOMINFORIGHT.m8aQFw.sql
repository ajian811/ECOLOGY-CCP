CREATE TRIGGER TR_CPCOMINFORIGHT
  BEFORE INSERT
  ON CPCOMINFORIGHT
  FOR EACH ROW
  begin select sq_cpcominforight.nextval into :new.id from dual; end;
/

