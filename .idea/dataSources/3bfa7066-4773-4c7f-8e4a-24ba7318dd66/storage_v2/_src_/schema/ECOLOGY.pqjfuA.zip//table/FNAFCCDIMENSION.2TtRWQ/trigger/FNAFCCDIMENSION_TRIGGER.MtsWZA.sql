CREATE TRIGGER FNAFCCDIMENSION_TRIGGER
  BEFORE INSERT
  ON FNAFCCDIMENSION
  FOR EACH ROW
  begin select seq_fccDimension.nextval into :new.id from dual; end;
/

