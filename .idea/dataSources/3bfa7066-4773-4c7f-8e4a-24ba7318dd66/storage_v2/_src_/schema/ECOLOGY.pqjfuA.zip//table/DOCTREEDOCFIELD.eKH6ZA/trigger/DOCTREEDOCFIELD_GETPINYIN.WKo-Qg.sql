CREATE TRIGGER DOCTREEDOCFIELD_GETPINYIN
  BEFORE INSERT OR UPDATE OF TREEDOCFIELDNAME
  ON DOCTREEDOCFIELD
  FOR EACH ROW
  begin select Lower(getpinyin((:new.treeDocFieldName))) into :new.ecology_pinyin_search from dual; end;
/

