CREATE TRIGGER EXP_XMLPROSETTINGS_TRI
  BEFORE INSERT
  ON EXP_XMLPROSETTINGS
  FOR EACH ROW
  begin select exp_XMLProSettings_id.nextval into :new.id from dual; end;
/

