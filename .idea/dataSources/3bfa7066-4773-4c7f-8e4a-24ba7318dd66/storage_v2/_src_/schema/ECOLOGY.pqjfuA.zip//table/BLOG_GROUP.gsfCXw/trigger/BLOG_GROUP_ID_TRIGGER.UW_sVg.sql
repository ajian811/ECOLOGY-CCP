CREATE TRIGGER BLOG_GROUP_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_GROUP
  FOR EACH ROW
  begin select blog_Group_id.nextval into :new.id from dual; end;
/

