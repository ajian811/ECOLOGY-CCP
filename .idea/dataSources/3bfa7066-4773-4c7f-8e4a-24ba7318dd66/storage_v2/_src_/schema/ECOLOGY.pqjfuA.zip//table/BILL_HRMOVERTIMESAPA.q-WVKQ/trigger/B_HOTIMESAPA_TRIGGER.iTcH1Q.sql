CREATE TRIGGER B_HOTIMESAPA_TRIGGER
  BEFORE INSERT
  ON BILL_HRMOVERTIMESAPA
  FOR EACH ROW
  begin select B_HOtimeSapa_id.nextval into :new.id from dual; end;
/

