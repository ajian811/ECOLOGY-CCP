CREATE TRIGGER DOCFTPCONFIG_TRIGGER
  BEFORE INSERT
  ON DOCFTPCONFIG
  FOR EACH ROW
  begin select DocFTPConfig_id.nextval into :new.id from dual; end;
/

