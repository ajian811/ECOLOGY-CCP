CREATE TRIGGER DATASHOWEXECUTELOG_TRI
  BEFORE INSERT
  ON DATASHOWEXECUTELOG
  FOR EACH ROW
  begin select datashowexecutelog_id.nextval into :new.id from dual; end;
/

