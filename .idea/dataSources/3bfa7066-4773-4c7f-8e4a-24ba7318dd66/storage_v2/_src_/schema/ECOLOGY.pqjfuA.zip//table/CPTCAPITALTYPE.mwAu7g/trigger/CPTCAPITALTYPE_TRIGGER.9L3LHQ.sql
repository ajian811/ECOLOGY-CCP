CREATE TRIGGER CPTCAPITALTYPE_TRIGGER
  BEFORE INSERT
  ON CPTCAPITALTYPE
  FOR EACH ROW
  begin select CptCapitalType_id.nextval into :new.id from dual; end;
/

