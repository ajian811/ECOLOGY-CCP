CREATE TRIGGER CRM_CONTRACT_TRIGGER
  BEFORE INSERT
  ON CRM_CONTRACT
  FOR EACH ROW
  begin select CRM_Contract_id.nextval into :new.id from dual; end;
/

