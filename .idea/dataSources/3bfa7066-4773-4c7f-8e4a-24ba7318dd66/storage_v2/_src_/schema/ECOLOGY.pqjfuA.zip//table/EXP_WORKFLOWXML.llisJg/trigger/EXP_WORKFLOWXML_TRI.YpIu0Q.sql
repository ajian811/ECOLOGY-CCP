CREATE TRIGGER EXP_WORKFLOWXML_TRI
  BEFORE INSERT
  ON EXP_WORKFLOWXML
  FOR EACH ROW
  begin select exp_workflowXML_id.nextval into :new.id from dual; end;
/

