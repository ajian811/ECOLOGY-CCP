CREATE VIEW HRMSUBCOMPANYALLVIEW AS
  SELECT id,subcompanyname,subcompanycode,subcompanydesc,supsubcomid,companyid,canceled,showorder,tlevel,companyid AS virtualtypeid,ecology_pinyin_search FROM HrmSubCompany UNION SELECT id,subcompanyname,subcompanycode,subcompanydesc,supsubcomid,companyid,canceled,showorder,tlevel,virtualtypeid,ecology_pinyin_search FROM HrmSubCompanyVirtual

/

