CREATE TRIGGER BILL_INNERSENDDOC_TRI
  BEFORE INSERT
  ON BILL_INNERSENDDOC
  FOR EACH ROW
  begin select bill_InnerSendDoc_id.nextval into :new.id from dual; end;
/

