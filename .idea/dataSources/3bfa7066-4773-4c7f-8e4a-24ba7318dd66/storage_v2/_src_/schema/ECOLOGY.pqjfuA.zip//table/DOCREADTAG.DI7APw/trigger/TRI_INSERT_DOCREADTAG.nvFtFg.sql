CREATE TRIGGER TRI_INSERT_DOCREADTAG
  AFTER INSERT OR UPDATE
  ON DOCREADTAG
  FOR EACH ROW
  Declare docid_1 integer; sumreadcount_2 integer;  begin docid_1 := :new.docid; update docdetail set sumreadcount = nvl(sumreadcount,0)+1 where id =docid_1; end;
/

