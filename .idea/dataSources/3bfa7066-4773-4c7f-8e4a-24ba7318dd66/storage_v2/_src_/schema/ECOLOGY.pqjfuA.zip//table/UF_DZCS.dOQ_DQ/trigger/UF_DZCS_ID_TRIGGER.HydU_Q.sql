CREATE TRIGGER UF_DZCS_ID_TRIGGER
  BEFORE INSERT
  ON UF_DZCS
  FOR EACH ROW
  begin select uf_dzcs_Id.nextval into :new.id from dual; end;
/

