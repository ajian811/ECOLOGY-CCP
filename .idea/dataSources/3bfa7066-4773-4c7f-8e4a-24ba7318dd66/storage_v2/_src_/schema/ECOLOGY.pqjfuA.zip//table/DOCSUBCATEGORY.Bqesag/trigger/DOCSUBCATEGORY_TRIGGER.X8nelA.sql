CREATE TRIGGER DOCSUBCATEGORY_TRIGGER
  BEFORE INSERT
  ON DOCSUBCATEGORY
  FOR EACH ROW
  begin select DocSubCategory_id.nextval INTO :new.id from dual; end;
/

