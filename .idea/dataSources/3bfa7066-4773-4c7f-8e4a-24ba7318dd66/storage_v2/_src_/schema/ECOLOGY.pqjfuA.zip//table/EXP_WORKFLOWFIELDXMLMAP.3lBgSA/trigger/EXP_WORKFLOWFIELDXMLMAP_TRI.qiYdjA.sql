CREATE TRIGGER EXP_WORKFLOWFIELDXMLMAP_TRI
  BEFORE INSERT
  ON EXP_WORKFLOWFIELDXMLMAP
  FOR EACH ROW
  begin select exp_workflowFieldXMLMap_id.nextval into :new.id from dual; end;
/

