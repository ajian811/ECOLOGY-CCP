CREATE TRIGGER BLOG_APPDATAS_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_APPDATAS
  FOR EACH ROW
  begin select blog_appDatas_id.nextval into :new.id from dual; end;
/

