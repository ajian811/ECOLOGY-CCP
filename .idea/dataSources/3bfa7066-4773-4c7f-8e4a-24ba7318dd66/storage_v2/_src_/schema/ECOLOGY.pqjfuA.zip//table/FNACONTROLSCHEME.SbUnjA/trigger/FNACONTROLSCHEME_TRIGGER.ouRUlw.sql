CREATE TRIGGER FNACONTROLSCHEME_TRIGGER
  BEFORE INSERT
  ON FNACONTROLSCHEME
  FOR EACH ROW
  begin select seq_fnaControlScheme_id.nextval into :new.id from dual; end;
/

