CREATE TRIGGER CRM_CONTRACT_EXCHANGE_TRIGGER
  BEFORE INSERT
  ON CRM_CONTRACT_EXCHANGE
  FOR EACH ROW
  begin select CRM_Contract_Exchange_id.nextval into :new.id from dual; end;
/

