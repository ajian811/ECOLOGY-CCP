CREATE TRIGGER ECOLOGYUPLIST_TRIGGER
  BEFORE INSERT
  ON ECOLOGYUPLIST
  FOR EACH ROW
  begin select ecologyuplist_id.nextval into :new.id from dual; end;
/

