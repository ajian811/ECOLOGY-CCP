CREATE TRIGGER "ecology_pagesize_id_TRIGGER"
  BEFORE INSERT
  ON ECOLOGY_PAGESIZE
  FOR EACH ROW
  begin select ecology_pagesize_id.nextval into :new.id from dual; end;
/

