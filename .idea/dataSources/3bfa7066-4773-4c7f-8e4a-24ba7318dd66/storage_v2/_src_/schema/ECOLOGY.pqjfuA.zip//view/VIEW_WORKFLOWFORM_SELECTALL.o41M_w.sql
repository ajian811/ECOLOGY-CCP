CREATE VIEW VIEW_WORKFLOWFORM_SELECTALL AS
  select id,formname,formdesc,subcompanyid,0 as isoldornew from workflow_formbase union all select t1.id,indexdesc,formdes,subcompanyid,1 as isoldornew from workflow_bill t1,HtmlLabelIndex t2 where t1.namelabel=t2.id

/

