CREATE TRIGGER BILL_ONLINEREGIST_TRIGGER
  BEFORE INSERT
  ON BILL_ONLINEREGIST
  FOR EACH ROW
  begin select bill_onlineRegist_id.nextval into :new.id from dual; end;
/

