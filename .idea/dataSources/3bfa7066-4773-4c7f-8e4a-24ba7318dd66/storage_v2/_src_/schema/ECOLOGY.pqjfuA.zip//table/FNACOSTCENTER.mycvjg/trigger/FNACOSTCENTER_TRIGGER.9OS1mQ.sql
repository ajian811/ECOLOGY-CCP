CREATE TRIGGER FNACOSTCENTER_TRIGGER
  BEFORE INSERT
  ON FNACOSTCENTER
  FOR EACH ROW
  begin select seq_FnaCostCenter_id.nextval into :new.id from dual; end;
/

