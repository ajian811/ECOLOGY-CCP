CREATE TRIGGER DOCSIGNATURE_TRIGGER
  BEFORE INSERT
  ON DOCSIGNATURE
  FOR EACH ROW
  begin select DocSignature_markId.nextval into :new.markId from dual; end;
/

