CREATE TRIGGER "elog_history_id_TRIGGER"
  BEFORE INSERT
  ON ECOLOGY_LOG_HISTORY
  FOR EACH ROW
  begin select ecology_log_history_id.nextval into :new.id from dual; end;
/

