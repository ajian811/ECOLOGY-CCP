CREATE TRIGGER BLOG_REPORTTEMP_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_REPORTTEMP
  FOR EACH ROW
  begin select blog_reportTemp_id.nextval into :new.id from dual; end;
/

