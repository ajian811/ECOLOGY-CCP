CREATE TRIGGER BLOG_LOCATION_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_LOCATION
  FOR EACH ROW
  begin select blog_location_id.nextval into :new.id from dual; end;
/

