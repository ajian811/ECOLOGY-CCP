CREATE TRIGGER ACTIONEXECUTELOG_TRI
  BEFORE INSERT
  ON ACTIONEXECUTELOG
  FOR EACH ROW
  begin select ActionExecuteLog_seq.nextval into :new.id from dual; end;
/

