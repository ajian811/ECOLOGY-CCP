CREATE TRIGGER FNABUDGETMODULE_TRIGGER
  BEFORE INSERT
  ON FNABUDGETMODULE
  FOR EACH ROW
  begin select FnaBudgetModule_id.nextval into :new.id from dual; end;
/

