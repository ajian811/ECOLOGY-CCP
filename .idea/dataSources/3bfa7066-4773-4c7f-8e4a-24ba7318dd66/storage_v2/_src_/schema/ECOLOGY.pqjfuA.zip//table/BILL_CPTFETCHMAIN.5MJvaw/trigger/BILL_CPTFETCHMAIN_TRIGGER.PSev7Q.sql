CREATE TRIGGER BILL_CPTFETCHMAIN_TRIGGER
  BEFORE INSERT
  ON BILL_CPTFETCHMAIN
  FOR EACH ROW
  begin select bill_CptFetchMain_id.nextval INTO :new.id from dual; end;
/

