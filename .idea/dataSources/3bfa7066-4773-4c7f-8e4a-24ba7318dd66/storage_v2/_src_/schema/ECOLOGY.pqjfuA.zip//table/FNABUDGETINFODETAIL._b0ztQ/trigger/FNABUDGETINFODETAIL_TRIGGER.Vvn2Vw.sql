CREATE TRIGGER FNABUDGETINFODETAIL_TRIGGER
  BEFORE INSERT
  ON FNABUDGETINFODETAIL
  FOR EACH ROW
  begin select FnaBudgetInfoDetail_id.nextval into :new.id from dual; end;
/

