CREATE TRIGGER CRM_COMMON_ATTENTION_ID_TRI
  BEFORE INSERT
  ON CRM_COMMON_ATTENTION
  FOR EACH ROW
  begin select CRM_Common_Attention_id.nextval into :new.id from dual; end;
/

