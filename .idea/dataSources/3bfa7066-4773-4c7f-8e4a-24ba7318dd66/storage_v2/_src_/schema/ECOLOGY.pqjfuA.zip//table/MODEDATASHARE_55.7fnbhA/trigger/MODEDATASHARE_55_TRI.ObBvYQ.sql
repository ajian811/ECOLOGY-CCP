CREATE TRIGGER MODEDATASHARE_55_TRI
  BEFORE INSERT
  ON MODEDATASHARE_55
  FOR EACH ROW
  begin   select modeDataShare_55_id.nextval into :new.id from dual;   end;
/

