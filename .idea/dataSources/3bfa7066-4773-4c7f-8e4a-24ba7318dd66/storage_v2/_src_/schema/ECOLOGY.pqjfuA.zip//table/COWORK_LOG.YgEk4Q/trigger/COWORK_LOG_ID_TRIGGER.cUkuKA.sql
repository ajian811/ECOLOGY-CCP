CREATE TRIGGER COWORK_LOG_ID_TRIGGER
  BEFORE INSERT
  ON COWORK_LOG
  FOR EACH ROW
  begin select cowork_log_id.nextval into :new.id from dual; end;
/

