CREATE TRIGGER FNAYEARSPERIODS_TRIGGER
  BEFORE INSERT
  ON FNAYEARSPERIODS
  FOR EACH ROW
  begin select FnaYearsPeriods_id.nextval INTO :new.id from dual; end;
/

