CREATE TRIGGER BLOG_USERGROUP_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_USERGROUP
  FOR EACH ROW
  begin select blog_userGroup_id.nextval into :new.id from dual; end;
/

