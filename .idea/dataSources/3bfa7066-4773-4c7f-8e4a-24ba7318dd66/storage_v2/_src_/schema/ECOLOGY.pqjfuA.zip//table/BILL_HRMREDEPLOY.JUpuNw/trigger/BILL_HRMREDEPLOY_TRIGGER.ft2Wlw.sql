CREATE TRIGGER BILL_HRMREDEPLOY_TRIGGER
  BEFORE INSERT
  ON BILL_HRMREDEPLOY
  FOR EACH ROW
  begin select Bill_HrmRedeploy_id.nextval INTO :new.id from dual; end;
/

