CREATE TRIGGER DOCSECCATEGORYCODERSEQ_TRI
  BEFORE INSERT
  ON DOCSECCATEGORYCODERSEQ
  FOR EACH ROW
  begin select DocSecCategoryCoderSeq_Id.nextval into :new.id from dual; end;
/

