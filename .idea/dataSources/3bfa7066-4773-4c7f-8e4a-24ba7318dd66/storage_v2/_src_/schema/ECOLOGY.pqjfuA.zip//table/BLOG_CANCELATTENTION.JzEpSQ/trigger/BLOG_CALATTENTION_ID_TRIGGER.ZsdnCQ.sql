CREATE TRIGGER BLOG_CALATTENTION_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_CANCELATTENTION
  FOR EACH ROW
  begin select blog_cancelAttention_id.nextval into :new.id from dual; end;
/

