CREATE TRIGGER DOCHTMLHIS_ID_TRIGGER
  BEFORE INSERT
  ON DOCPREVIEWHTMLHISTORY
  FOR EACH ROW
  begin select DocHtmlHis_id.nextval into :new.id from dual; end;
/

