CREATE TRIGGER DOCSENDDOCNUMBER_TRI
  BEFORE INSERT
  ON DOCSENDDOCNUMBER
  FOR EACH ROW
  begin select DocSendDocNumber_id.nextval into :new.id from dual; end;
/

