CREATE TRIGGER BILL_VOTINGAPPROVE_TRIGGER
  BEFORE INSERT
  ON BILL_VOTINGAPPROVE
  FOR EACH ROW
  begin select bill_VotingApprove_Id.nextval into :new.id from dual; end;
/

