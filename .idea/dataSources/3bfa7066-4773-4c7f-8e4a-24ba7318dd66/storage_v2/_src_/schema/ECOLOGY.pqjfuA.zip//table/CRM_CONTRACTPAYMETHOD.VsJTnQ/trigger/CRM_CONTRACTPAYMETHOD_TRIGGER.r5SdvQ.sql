CREATE TRIGGER CRM_CONTRACTPAYMETHOD_TRIGGER
  BEFORE INSERT
  ON CRM_CONTRACTPAYMETHOD
  FOR EACH ROW
  begin select CRM_ContractPayMethod_id.nextval into :new.id from dual; end;
/

