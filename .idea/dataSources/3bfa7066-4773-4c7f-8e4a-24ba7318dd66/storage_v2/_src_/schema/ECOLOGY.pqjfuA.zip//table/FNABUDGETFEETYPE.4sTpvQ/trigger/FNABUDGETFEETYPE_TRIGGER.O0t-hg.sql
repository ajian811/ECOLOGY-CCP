CREATE TRIGGER FNABUDGETFEETYPE_TRIGGER
  BEFORE INSERT
  ON FNABUDGETFEETYPE
  FOR EACH ROW
  begin select FnaBudgetfeeType_id.nextval into :new.id from dual; end;
/

