CREATE TRIGGER BUDGETAUTOMOVE_ID_TRI
  BEFORE INSERT
  ON BUDGETAUTOMOVE
  FOR EACH ROW
  begin select BudgetAutoMove_Id.nextval into :new.id from dual; end;
/

