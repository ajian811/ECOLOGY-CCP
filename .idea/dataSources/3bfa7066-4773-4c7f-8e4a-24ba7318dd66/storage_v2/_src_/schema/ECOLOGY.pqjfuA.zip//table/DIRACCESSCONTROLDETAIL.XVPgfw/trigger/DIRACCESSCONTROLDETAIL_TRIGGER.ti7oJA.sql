CREATE TRIGGER DIRACCESSCONTROLDETAIL_TRIGGER
  BEFORE INSERT
  ON DIRACCESSCONTROLDETAIL
  FOR EACH ROW
  begin select DirAccessControlDetail_id.nextval into :new.id from dual; end;
/

