CREATE TRIGGER BLOG_APPITEM_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_APPITEM
  FOR EACH ROW
  begin select blog_AppItem_id.nextval into :new.id from dual; end;
/

