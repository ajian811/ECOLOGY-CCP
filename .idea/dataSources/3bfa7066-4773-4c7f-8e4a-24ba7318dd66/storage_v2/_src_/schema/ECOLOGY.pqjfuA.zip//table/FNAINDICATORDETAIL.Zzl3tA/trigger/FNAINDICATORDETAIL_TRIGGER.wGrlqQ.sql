CREATE TRIGGER FNAINDICATORDETAIL_TRIGGER
  BEFORE INSERT
  ON FNAINDICATORDETAIL
  FOR EACH ROW
  begin select FnaIndicatordetail_id.nextval into :new.id from dual; end;
/

