CREATE TRIGGER FNACOSTCENTERDTL_TRIGGER
  BEFORE INSERT
  ON FNACOSTCENTERDTL
  FOR EACH ROW
  begin select seq_FnaCostCenterDtl_id.nextval into :new.id from dual; end;
/

