CREATE TRIGGER CRM_LABEL_ID_TRIGGER
  BEFORE INSERT
  ON CRM_LABEL
  FOR EACH ROW
  begin select CRM_label_id.nextval into :new.id from dual; end;
/

