CREATE TRIGGER FM_13_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_13
  FOR EACH ROW
  begin 
   select fm_13_ID.nextval into :new.id from dual; 
 end;
/

