CREATE TRIGGER DOCUSERDEFAULT_TRIGGER
  BEFORE INSERT
  ON DOCUSERDEFAULT
  FOR EACH ROW
  begin select DocUserDefault_id.nextval into:new.id from dual; end;
/

