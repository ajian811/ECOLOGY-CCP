CREATE TRIGGER FNADATASET_TRIGGER
  BEFORE INSERT
  ON FNADATASET
  FOR EACH ROW
  begin select seq_fnaDataSet_id.nextval into :new.id from dual; end;
/

