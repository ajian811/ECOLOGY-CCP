CREATE TRIGGER ECOLOGYPACKAGEINFO_TRIGGER
  BEFORE INSERT
  ON ECOLOGYPACKAGEINFO
  FOR EACH ROW
  begin select ecologypackageinfo_id.nextval into :new.id from dual; end;
/

