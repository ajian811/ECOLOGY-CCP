CREATE TRIGGER BILL_BOHAIOUT_TRIGGER
  BEFORE INSERT
  ON BILL_BOHAIOUT
  FOR EACH ROW
  begin select Bill_BoHaiOut_id.nextval into :new.id from dual; end;
/

