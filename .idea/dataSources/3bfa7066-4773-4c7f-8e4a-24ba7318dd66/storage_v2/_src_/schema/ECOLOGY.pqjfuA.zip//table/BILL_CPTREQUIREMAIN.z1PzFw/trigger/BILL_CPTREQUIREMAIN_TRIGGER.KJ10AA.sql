CREATE TRIGGER BILL_CPTREQUIREMAIN_TRIGGER
  BEFORE INSERT
  ON BILL_CPTREQUIREMAIN
  FOR EACH ROW
  begin select bill_CptRequireMain_id.nextval INTO :new.id from dual; end;
/

