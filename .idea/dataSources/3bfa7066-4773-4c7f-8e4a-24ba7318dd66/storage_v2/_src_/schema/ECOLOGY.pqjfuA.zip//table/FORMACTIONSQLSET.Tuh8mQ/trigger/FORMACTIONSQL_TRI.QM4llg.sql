CREATE TRIGGER FORMACTIONSQL_TRI
  BEFORE INSERT
  ON FORMACTIONSQLSET
  FOR EACH ROW
  begin select formactionsql_seq.nextval into :new.id from dual; end;
/

