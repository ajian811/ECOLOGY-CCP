CREATE TRIGGER COWORK_LABEL_ID_TRIGGER
  BEFORE INSERT
  ON COWORK_LABEL
  FOR EACH ROW
  begin select cowork_label_id.nextval into:New.id from dual; end;
/

