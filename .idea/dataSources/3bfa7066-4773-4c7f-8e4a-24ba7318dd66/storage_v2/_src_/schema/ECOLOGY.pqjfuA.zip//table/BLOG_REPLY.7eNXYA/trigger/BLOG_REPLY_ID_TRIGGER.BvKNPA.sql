CREATE TRIGGER BLOG_REPLY_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_REPLY
  FOR EACH ROW
  begin select blog_reply_id.nextval into :new.id from dual; end;
/

