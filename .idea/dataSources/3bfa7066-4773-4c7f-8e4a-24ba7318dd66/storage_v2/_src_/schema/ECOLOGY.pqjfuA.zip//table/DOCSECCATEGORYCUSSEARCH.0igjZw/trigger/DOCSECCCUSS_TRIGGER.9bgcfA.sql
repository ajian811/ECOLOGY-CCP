CREATE TRIGGER DOCSECCCUSS_TRIGGER
  BEFORE INSERT
  ON DOCSECCATEGORYCUSSEARCH
  FOR EACH ROW
  begin select DocSecCategoryCusSearch_id.nextval into :new.id from dual; end ;
/

