CREATE TRIGGER ELEMENTSETTING_ID_TRI
  BEFORE INSERT
  ON ELEMENTSETTING
  FOR EACH ROW
  begin select elementsetting_id.nextval into :new.id from dual; end;
/

