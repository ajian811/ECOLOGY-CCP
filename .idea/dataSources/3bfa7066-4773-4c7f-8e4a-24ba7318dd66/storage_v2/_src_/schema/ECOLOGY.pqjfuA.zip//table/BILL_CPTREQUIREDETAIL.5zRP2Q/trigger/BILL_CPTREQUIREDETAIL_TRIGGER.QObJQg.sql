CREATE TRIGGER BILL_CPTREQUIREDETAIL_TRIGGER
  BEFORE INSERT
  ON BILL_CPTREQUIREDETAIL
  FOR EACH ROW
  begin select bill_CptRequireDetail_id.nextval INTO :new.id from dual; end;
/

