CREATE TRIGGER BILL_MEETING_DT1_TOPIC_TR
  BEFORE INSERT
  ON BILL_MEETING_DT1_TOPIC
  FOR EACH ROW
  begin select Bill_Meeting_dt1_Topic_ID.nextval into :new.id from dual; end;
/

