CREATE TRIGGER CRM_TRADEINFO_TRIGGER
  BEFORE INSERT
  ON CRM_TRADEINFO
  FOR EACH ROW
  begin select CRM_TradeInfo_id.nextval into :new.id from dual; end;
/

