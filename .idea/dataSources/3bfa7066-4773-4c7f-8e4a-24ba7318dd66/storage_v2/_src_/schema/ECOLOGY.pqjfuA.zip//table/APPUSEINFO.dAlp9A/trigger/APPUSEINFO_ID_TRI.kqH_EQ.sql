CREATE TRIGGER APPUSEINFO_ID_TRI
  BEFORE INSERT
  ON APPUSEINFO
  FOR EACH ROW
  begin select AppUseInfo_id.nextval into :new.id from dual; end;
/

