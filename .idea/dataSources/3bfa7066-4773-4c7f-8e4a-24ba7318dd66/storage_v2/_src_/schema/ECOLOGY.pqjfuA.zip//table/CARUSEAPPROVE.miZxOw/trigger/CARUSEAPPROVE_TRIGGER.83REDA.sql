CREATE TRIGGER CARUSEAPPROVE_TRIGGER
  BEFORE INSERT
  ON CARUSEAPPROVE
  FOR EACH ROW
  begin select CarUseApprove_id.nextval into :new.id from dual; end ;
/

