CREATE TRIGGER EXP_LOCALDETAIL_TRI
  BEFORE INSERT
  ON EXP_LOCALDETAIL
  FOR EACH ROW
  begin select exp_localdetail_id.nextval into :new.id from dual; end;
/

