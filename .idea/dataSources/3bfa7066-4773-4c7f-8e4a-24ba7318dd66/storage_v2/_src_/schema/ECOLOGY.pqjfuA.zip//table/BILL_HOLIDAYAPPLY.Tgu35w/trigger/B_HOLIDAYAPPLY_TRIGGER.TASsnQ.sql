CREATE TRIGGER B_HOLIDAYAPPLY_TRIGGER
  BEFORE INSERT
  ON BILL_HOLIDAYAPPLY
  FOR EACH ROW
  begin select B_HolidayApply_id.nextval into :new.id from dual; end;
/

