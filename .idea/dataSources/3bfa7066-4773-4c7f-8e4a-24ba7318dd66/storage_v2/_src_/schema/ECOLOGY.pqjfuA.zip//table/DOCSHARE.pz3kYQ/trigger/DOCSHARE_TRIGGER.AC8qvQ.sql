CREATE TRIGGER DOCSHARE_TRIGGER
  BEFORE INSERT
  ON DOCSHARE
  FOR EACH ROW
  begin select DocShare_id.nextval INTO :new.id from dual; end;
/

