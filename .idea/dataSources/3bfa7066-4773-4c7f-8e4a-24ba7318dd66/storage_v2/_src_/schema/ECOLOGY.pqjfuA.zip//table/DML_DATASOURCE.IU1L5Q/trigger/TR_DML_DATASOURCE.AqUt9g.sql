CREATE TRIGGER TR_DML_DATASOURCE
  BEFORE INSERT
  ON DML_DATASOURCE
  FOR EACH ROW
  begin select sq_dml_datasource.nextval into :new.id from dual; end;
/

