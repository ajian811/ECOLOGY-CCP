CREATE TRIGGER DOCMAILMOULD_TRIGGER
  BEFORE INSERT
  ON DOCMAILMOULD
  FOR EACH ROW
  begin select DocMailMould_id.nextval into:new.id from dual; end;
/

