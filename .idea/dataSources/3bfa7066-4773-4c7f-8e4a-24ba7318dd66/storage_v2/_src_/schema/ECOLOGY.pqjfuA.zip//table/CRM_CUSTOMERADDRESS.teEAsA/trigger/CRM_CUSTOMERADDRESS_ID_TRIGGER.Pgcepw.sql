CREATE TRIGGER CRM_CUSTOMERADDRESS_ID_TRIGGER
  BEFORE INSERT
  ON CRM_CUSTOMERADDRESS
  FOR EACH ROW
  begin select CRM_CustomerAddress_id.nextval into :new.id from dual; end;
/

