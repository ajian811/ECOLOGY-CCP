CREATE TRIGGER BILL_HRMSCHEDULEMAIN_TRIGGER
  BEFORE INSERT
  ON BILL_HRMSCHEDULEMAIN
  FOR EACH ROW
  begin select Bill_HrmScheduleMain_id.nextval into :new.id from dual; end;
/

