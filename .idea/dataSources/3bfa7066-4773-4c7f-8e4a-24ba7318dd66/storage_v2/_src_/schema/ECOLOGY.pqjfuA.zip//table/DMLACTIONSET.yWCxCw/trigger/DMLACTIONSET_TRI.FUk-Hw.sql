CREATE TRIGGER DMLACTIONSET_TRI
  BEFORE INSERT
  ON DMLACTIONSET
  FOR EACH ROW
  begin select dmlactionset_seq.nextval into :new.id from dual; end;
/

