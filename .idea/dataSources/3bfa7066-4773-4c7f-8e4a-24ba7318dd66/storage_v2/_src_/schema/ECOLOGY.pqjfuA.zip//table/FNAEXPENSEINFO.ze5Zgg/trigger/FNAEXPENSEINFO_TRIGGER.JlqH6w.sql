CREATE TRIGGER FNAEXPENSEINFO_TRIGGER
  BEFORE INSERT
  ON FNAEXPENSEINFO
  FOR EACH ROW
  begin select FnaExpenseInfo_id.nextval into :new.id from dual; end;
/

