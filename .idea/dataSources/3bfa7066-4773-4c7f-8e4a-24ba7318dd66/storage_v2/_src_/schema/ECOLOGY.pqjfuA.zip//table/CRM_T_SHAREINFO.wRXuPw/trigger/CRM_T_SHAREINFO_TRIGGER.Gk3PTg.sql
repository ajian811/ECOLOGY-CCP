CREATE TRIGGER CRM_T_SHAREINFO_TRIGGER
  BEFORE INSERT
  ON CRM_T_SHAREINFO
  FOR EACH ROW
  begin select CRM_T_ShareInfo_id.nextval into :new.id from dual; end;
/

