CREATE TRIGGER BLOG_REMIND_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_REMIND
  FOR EACH ROW
  begin select blog_remind_id.nextval into :new.id from dual; end;
/

