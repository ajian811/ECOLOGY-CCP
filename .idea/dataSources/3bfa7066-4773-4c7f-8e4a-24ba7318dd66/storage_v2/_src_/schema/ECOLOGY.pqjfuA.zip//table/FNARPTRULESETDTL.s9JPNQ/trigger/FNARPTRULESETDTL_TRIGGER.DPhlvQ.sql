CREATE TRIGGER FNARPTRULESETDTL_TRIGGER
  BEFORE INSERT
  ON FNARPTRULESETDTL
  FOR EACH ROW
  begin select seq_fnaRptRuleSetDtl_id.nextval into :new.id from dual; end;
/

