CREATE TRIGGER FORMTABLE_MAIN_21_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_21
  FOR EACH ROW
  begin select formtable_main_21_Id.nextval into :new.id from dual; 
 end;
/

