CREATE TRIGGER BILL_FNALOANAPPLY_TRIGGER
  BEFORE INSERT
  ON BILL_FNALOANAPPLY
  FOR EACH ROW
  begin select Bill_FnaLoanApply_id.nextval into :new.id from dual; end;
/

