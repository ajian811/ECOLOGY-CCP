CREATE TRIGGER DATASEARCHPARAM_TRI
  BEFORE INSERT
  ON DATASEARCHPARAM
  FOR EACH ROW
  begin select datasearchparam_seq.nextval into :new.id from dual; end;
/

