CREATE TRIGGER CRM_EVALUATION_LEVEL_TRIGGER
  BEFORE INSERT
  ON CRM_EVALUATION_LEVEL
  FOR EACH ROW
  begin select CRM_Evaluation_Level_id.nextval into :new.id from dual; end;
/

