CREATE TRIGGER CPTCODESET1_TRIGGER
  BEFORE INSERT
  ON CPTCODESET1
  FOR EACH ROW
  begin select cptcodeset1_ID.nextval into :new.id from dual; end;
/

