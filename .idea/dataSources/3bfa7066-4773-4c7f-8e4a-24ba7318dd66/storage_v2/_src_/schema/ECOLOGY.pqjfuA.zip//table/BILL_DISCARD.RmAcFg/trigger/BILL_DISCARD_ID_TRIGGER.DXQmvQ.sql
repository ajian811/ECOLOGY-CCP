CREATE TRIGGER BILL_DISCARD_ID_TRIGGER
  BEFORE INSERT
  ON BILL_DISCARD
  FOR EACH ROW
  begin select bill_Discard_Id.nextval into :new.id from dual; end;
/

