CREATE TRIGGER ALBUMPHOTOREVIEW_TRIGGER
  BEFORE INSERT
  ON ALBUMPHOTOREVIEW
  FOR EACH ROW
  begin select AlbumPhotoReview_id.nextval into :new.id from dual; end ;
/

