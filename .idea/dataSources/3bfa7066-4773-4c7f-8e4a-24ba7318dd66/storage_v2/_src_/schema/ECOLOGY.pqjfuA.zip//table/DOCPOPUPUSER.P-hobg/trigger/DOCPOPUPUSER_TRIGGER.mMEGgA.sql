CREATE TRIGGER DOCPOPUPUSER_TRIGGER
  BEFORE INSERT
  ON DOCPOPUPUSER
  FOR EACH ROW
  begin select DocPopUpUser_id.nextval into :new.id from dual; end;
/

