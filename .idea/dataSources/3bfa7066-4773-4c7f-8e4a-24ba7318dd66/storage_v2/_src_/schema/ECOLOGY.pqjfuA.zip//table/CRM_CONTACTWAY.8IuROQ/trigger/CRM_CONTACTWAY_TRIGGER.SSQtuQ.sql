CREATE TRIGGER CRM_CONTACTWAY_TRIGGER
  BEFORE INSERT
  ON CRM_CONTACTWAY
  FOR EACH ROW
  begin select CRM_ContactWay_id.nextval into :new.id from dual; end;
/

