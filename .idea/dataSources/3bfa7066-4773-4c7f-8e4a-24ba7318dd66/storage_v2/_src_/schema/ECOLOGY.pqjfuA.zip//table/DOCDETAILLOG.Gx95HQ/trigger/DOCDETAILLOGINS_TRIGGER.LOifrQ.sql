CREATE TRIGGER DOCDETAILLOGINS_TRIGGER
  AFTER INSERT
  ON DOCDETAILLOG
  FOR EACH ROW
  begin SysMaintenanceLog_proc(:new.docid, :new.docsubject, :new.operateuserid , :new.usertype, :new.operatetype, '', '301', :new.operatedate, :new.operatetime, 1, :new.clientaddress, 0 ); end;
/

