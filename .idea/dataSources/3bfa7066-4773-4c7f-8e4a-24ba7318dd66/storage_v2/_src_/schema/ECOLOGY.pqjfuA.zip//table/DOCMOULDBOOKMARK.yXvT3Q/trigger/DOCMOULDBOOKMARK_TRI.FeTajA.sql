CREATE TRIGGER DOCMOULDBOOKMARK_TRI
  BEFORE INSERT
  ON DOCMOULDBOOKMARK
  FOR EACH ROW
  begin select DocMouldBookMark_Id.nextval into :new.id from dual; end;
/

