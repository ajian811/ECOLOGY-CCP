CREATE TRIGGER BILL_RETURNCPT_TRI
  BEFORE INSERT
  ON BILL_MENDCPT
  FOR EACH ROW
  begin select bill_returncpt_id.nextval into :new.id from dual; end;
/

