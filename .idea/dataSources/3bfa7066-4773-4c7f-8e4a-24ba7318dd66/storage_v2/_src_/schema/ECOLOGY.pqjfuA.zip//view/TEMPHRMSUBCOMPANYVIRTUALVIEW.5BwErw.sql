CREATE VIEW TEMPHRMSUBCOMPANYVIRTUALVIEW AS
  select id, supsubcomid, level templevel from HrmSubCompanyVirtual start with nvl(supsubcomid,0) = 0 connect by prior id = supsubcomid

/

