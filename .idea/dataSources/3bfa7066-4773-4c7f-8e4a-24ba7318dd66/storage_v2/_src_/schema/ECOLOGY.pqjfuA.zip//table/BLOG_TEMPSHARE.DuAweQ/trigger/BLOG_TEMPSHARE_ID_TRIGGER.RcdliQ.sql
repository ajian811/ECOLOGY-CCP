CREATE TRIGGER BLOG_TEMPSHARE_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_TEMPSHARE
  FOR EACH ROW
  begin select blog_tempShare_id.nextval into :new.id from dual; end;
/

