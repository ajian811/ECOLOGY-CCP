CREATE TRIGGER B_FPAPPLY_TRIGGER
  BEFORE INSERT
  ON BILL_FNAPAYAPPLY
  FOR EACH ROW
  begin select Bill_FnaPayApply_id.nextval into :new.id from dual; end;
/

