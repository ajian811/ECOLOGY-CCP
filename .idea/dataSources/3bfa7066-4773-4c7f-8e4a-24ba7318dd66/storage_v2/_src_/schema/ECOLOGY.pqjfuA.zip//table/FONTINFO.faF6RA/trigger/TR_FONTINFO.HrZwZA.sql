CREATE TRIGGER TR_FONTINFO
  BEFORE INSERT
  ON FONTINFO
  FOR EACH ROW
  begin select sq_fontinfo.nextval into :new.id from dual; end;
/

