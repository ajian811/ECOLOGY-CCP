CREATE TRIGGER DOCCHECKINOUT_ID_TRI
  BEFORE INSERT
  ON DOCCHECKINOUT
  FOR EACH ROW
  begin select DocCheckInOut_id.nextval into :new.id from dual; end;
/

