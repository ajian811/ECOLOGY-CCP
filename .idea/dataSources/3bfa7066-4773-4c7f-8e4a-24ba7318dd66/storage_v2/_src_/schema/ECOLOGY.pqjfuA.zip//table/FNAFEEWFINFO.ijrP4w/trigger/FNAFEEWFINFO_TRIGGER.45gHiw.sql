CREATE TRIGGER FNAFEEWFINFO_TRIGGER
  BEFORE INSERT
  ON FNAFEEWFINFO
  FOR EACH ROW
  begin select seq_fnaFeeWfInfo_id.nextval into :new.id from dual; end;
/

