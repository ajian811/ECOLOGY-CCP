CREATE TRIGGER CPTCODESET_TRIGGER
  BEFORE INSERT
  ON CPTCODESET
  FOR EACH ROW
  begin select cptcodeset_id.nextval into :new.id from dual; end;
/

