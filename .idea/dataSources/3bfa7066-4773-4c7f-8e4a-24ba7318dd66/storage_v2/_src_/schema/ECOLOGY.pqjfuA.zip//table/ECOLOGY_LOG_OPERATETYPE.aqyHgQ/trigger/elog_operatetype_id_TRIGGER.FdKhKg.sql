CREATE TRIGGER "elog_operatetype_id_TRIGGER"
  BEFORE INSERT
  ON ECOLOGY_LOG_OPERATETYPE
  FOR EACH ROW
  begin select ecology_log_operatetype_id.nextval into :new.id from dual; end;
/

