CREATE TRIGGER FNAVOUCHERXML_TRIGGER
  BEFORE INSERT
  ON FNAVOUCHERXML
  FOR EACH ROW
  begin select seq_fnaVoucherXml_id.nextval into :new.id from dual; end;
/

