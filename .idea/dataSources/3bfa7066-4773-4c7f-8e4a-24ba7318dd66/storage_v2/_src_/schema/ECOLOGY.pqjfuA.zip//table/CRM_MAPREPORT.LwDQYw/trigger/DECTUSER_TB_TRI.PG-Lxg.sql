CREATE TRIGGER DECTUSER_TB_TRI
  BEFORE INSERT
  ON CRM_MAPREPORT
  FOR EACH ROW
  begin select dectuser_tb_seq.nextval into :new.id from dual; end;
/

