CREATE TRIGGER CODEDETAIL_TRIGGER
  BEFORE INSERT
  ON CODEDETAIL
  FOR EACH ROW
  begin select codedetail_id.nextval into :new.id from dual; end;
/

