CREATE TRIGGER FM_14_DT1_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_14_DT1
  FOR EACH ROW
  begin    select fm_14_DT1_ID.nextval into :new.id from dual;  end;
/

