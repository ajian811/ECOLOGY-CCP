CREATE TRIGGER BILL_SENDDOC_TRI
  BEFORE INSERT
  ON BILL_SENDDOC
  FOR EACH ROW
  begin select bill_SendDoc_id.nextval into :new.id from dual; end;
/

