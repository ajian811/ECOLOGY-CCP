CREATE TRIGGER CRM_ADDRESSTYPE_TRIGGER
  BEFORE INSERT
  ON CRM_ADDRESSTYPE
  FOR EACH ROW
  begin select CRM_AddressType_id.nextval into :new.id from dual; end;
/

