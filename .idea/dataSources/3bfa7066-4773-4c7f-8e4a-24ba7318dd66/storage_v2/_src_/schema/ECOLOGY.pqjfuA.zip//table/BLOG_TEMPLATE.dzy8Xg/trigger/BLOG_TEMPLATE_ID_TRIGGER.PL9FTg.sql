CREATE TRIGGER BLOG_TEMPLATE_ID_TRIGGER
  BEFORE INSERT
  ON BLOG_TEMPLATE
  FOR EACH ROW
  begin select blog_template_id.nextval into :new.id from dual; end;
/

