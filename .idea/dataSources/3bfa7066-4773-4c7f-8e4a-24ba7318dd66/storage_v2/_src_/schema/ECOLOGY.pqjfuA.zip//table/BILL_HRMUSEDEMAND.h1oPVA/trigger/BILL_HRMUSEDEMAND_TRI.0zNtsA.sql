CREATE TRIGGER BILL_HRMUSEDEMAND_TRI
  BEFORE INSERT
  ON BILL_HRMUSEDEMAND
  FOR EACH ROW
  begin select Bill_HrmUseDemand_id.nextval INTO :new.id from dual; end;
/

