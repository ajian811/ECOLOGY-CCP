CREATE TRIGGER BILL_APPROVEPROJ_TRI
  BEFORE INSERT
  ON BILL_APPROVEPROJ
  FOR EACH ROW
  begin select Bill_ApproveProj_id.nextval into :new.id from dual; end;
/

