CREATE TRIGGER BILL_APPROVECUSTOMER_TRI
  BEFORE INSERT
  ON BILL_APPROVECUSTOMER
  FOR EACH ROW
  begin select bill_ApproveCustomer_id.nextval into :new.id from dual; end;
/

