CREATE TRIGGER CPTSTOCKINMAIN_TRIGGER
  BEFORE INSERT
  ON CPTSTOCKINMAIN
  FOR EACH ROW
  begin select CptStockInMain_id.nextval into :new.id from dual; end;
/

