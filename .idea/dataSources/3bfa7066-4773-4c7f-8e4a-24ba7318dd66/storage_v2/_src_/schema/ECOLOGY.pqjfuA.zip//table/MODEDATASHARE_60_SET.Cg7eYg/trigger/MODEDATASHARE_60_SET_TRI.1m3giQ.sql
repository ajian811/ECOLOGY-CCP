CREATE TRIGGER MODEDATASHARE_60_SET_TRI
  BEFORE INSERT
  ON MODEDATASHARE_60_SET
  FOR EACH ROW
  begin   select modeDataShare_60_set_id.nextval into :new.id from dual;   end;
/

