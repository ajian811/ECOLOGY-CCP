CREATE TRIGGER FORMTABLE_MAIN_21_DT1_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_21_DT1
  FOR EACH ROW
  begin select formtable_main_21_dt1_Id.nextval into :new.id from dual; end;
/

