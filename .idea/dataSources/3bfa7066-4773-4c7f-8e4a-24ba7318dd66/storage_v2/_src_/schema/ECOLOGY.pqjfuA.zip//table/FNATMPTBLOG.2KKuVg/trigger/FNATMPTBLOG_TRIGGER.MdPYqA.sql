CREATE TRIGGER FNATMPTBLOG_TRIGGER
  BEFORE INSERT
  ON FNATMPTBLOG
  FOR EACH ROW
  begin select fnaTmpTbLog_ID.nextval INTO :new.id from dual; end;
/

