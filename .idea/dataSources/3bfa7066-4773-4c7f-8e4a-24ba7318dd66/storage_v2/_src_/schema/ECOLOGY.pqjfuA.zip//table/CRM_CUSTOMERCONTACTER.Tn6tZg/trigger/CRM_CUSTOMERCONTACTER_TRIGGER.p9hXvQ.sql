CREATE TRIGGER CRM_CUSTOMERCONTACTER_TRIGGER
  BEFORE INSERT
  ON CRM_CUSTOMERCONTACTER
  FOR EACH ROW
  begin select CRM_CustomerContacter_id.nextval into :new.id from dual; end;
/

