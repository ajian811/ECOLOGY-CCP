CREATE TRIGGER CODEMAIN_TRIGGER
  BEFORE INSERT
  ON CODEMAIN
  FOR EACH ROW
  begin select codemain_id.nextval into :new.id from dual; end;
/

