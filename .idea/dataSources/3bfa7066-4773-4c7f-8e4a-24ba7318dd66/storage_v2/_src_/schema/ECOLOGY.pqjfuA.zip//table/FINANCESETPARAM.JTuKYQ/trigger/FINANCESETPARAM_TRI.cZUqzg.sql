CREATE TRIGGER FINANCESETPARAM_TRI
  BEFORE INSERT
  ON FINANCESETPARAM
  FOR EACH ROW
  begin select financesetparam_seq.nextval into :new.id from dual; end;
/

