CREATE TRIGGER FM_2_DT4_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_2_DT4
  FOR EACH ROW
  begin    select fm_2_DT4_ID.nextval into :new.id from dual;  end;
/

