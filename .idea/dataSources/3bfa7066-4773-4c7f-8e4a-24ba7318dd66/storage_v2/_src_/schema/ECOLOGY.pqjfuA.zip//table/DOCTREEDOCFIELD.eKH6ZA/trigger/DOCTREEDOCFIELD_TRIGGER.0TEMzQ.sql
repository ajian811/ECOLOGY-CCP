CREATE TRIGGER DOCTREEDOCFIELD_TRIGGER
  BEFORE INSERT
  ON DOCTREEDOCFIELD
  FOR EACH ROW
  begin select DocTreeDocField_Id.nextval into :new.id from dual; end;
/

