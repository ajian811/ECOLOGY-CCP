CREATE TRIGGER DOC_PROP_TRIGGER
  BEFORE INSERT
  ON DOC_PROP
  FOR EACH ROW
  begin SELECT doc_prop_id.nextval INTO:new.id from dual; end;
/

