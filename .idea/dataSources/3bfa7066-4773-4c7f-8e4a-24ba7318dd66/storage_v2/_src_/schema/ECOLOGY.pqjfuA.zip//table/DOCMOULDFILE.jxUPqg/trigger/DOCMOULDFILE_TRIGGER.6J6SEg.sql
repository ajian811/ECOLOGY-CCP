CREATE TRIGGER DOCMOULDFILE_TRIGGER
  BEFORE INSERT
  ON DOCMOULDFILE
  FOR EACH ROW
  begin select DocMouldFile_id.nextval INTO :new.id from dual; end;
/

