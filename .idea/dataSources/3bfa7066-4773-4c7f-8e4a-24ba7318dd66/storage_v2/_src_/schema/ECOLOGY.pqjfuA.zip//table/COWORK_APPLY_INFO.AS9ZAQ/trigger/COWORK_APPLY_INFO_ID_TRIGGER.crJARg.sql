CREATE TRIGGER COWORK_APPLY_INFO_ID_TRIGGER
  BEFORE INSERT
  ON COWORK_APPLY_INFO
  FOR EACH ROW
  begin select cowork_apply_info_id.nextval into :new.id from dual; end;
/

