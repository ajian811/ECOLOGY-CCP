CREATE TRIGGER MODEDATASHARE_902_TRI
  BEFORE INSERT
  ON MODEDATASHARE_902
  FOR EACH ROW
  begin   select modeDataShare_902_id.nextval into :new.id from dual;   end;
/

