CREATE TRIGGER EXP_DBPROSETTINGS_TRI
  BEFORE INSERT
  ON EXP_DBPROSETTINGS
  FOR EACH ROW
  begin select exp_DBProSettings_id.nextval into :new.id from dual; end;
/

