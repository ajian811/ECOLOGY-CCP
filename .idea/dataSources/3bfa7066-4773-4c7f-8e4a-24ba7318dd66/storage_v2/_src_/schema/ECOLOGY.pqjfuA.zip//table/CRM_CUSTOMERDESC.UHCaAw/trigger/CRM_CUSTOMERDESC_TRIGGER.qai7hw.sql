CREATE TRIGGER CRM_CUSTOMERDESC_TRIGGER
  BEFORE INSERT
  ON CRM_CUSTOMERDESC
  FOR EACH ROW
  begin select CRM_CustomerDesc_id.nextval into :new.id from dual; end;
/

