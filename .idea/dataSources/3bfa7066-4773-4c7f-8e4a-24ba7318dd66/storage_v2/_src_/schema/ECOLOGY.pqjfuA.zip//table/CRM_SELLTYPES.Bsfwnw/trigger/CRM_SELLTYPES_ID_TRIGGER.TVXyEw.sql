CREATE TRIGGER CRM_SELLTYPES_ID_TRIGGER
  BEFORE INSERT
  ON CRM_SELLTYPES
  FOR EACH ROW
  begin select CRM_SellTypes_id.nextval into :new.id from dual; end;
/

