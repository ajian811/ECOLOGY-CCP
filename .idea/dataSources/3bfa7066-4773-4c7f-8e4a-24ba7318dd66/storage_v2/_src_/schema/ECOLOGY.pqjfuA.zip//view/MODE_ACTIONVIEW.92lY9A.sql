CREATE VIEW MODE_ACTIONVIEW AS
  select d.id, d.dmlactionname as actionname, d.dmlorder as actionorder, d.modeid, d.expandid, 0 as actiontype from mode_dmlactionset d union select w.id, w.actionname, w.actionorder, w.modeid, w.expandid, 1 as actiontype from mode_wsactionset w union select s.id, s.actionname, s.actionorder, s.modeid, s.expandid, 2 as actiontype from mode_sapactionset s

/

