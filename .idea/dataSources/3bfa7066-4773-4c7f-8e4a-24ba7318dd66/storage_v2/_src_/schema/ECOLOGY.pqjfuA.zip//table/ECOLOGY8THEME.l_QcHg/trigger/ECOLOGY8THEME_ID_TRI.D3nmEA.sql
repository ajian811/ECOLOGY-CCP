CREATE TRIGGER ECOLOGY8THEME_ID_TRI
  BEFORE INSERT
  ON ECOLOGY8THEME
  FOR EACH ROW
  begin select ecology8theme_id.nextval into :new.id from dual; end;
/

