CREATE TRIGGER CPTCAPITALASSORTMENT_TRIGGER
  BEFORE INSERT
  ON CPTCAPITALASSORTMENT
  FOR EACH ROW
  begin select CptCapitalAssortment_id.nextval into :new.id from dual; end;
/

