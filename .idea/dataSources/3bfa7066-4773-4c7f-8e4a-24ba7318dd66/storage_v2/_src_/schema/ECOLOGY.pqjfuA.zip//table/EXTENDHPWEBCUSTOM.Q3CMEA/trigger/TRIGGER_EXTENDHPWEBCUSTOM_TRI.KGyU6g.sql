CREATE TRIGGER TRIGGER_EXTENDHPWEBCUSTOM_TRI
  BEFORE INSERT
  ON EXTENDHPWEBCUSTOM
  FOR EACH ROW
  begin select extendHpWebCustom_id.nextval into :new.id from dual; end;
/

