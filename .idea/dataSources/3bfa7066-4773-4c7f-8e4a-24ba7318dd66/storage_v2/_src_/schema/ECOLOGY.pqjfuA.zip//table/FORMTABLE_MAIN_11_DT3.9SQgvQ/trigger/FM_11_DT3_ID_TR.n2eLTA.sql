CREATE TRIGGER FM_11_DT3_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_11_DT3
  FOR EACH ROW
  begin    select fm_11_DT3_ID.nextval into :new.id from dual;  end;
/

