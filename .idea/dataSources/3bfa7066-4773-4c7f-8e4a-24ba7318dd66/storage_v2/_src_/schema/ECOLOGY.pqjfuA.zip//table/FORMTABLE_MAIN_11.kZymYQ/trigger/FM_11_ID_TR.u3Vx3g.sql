CREATE TRIGGER FM_11_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_11
  FOR EACH ROW
  begin 
   select fm_11_ID.nextval into :new.id from dual; 
 end;
/

