CREATE TRIGGER MODEDATASHARE_60_TRI
  BEFORE INSERT
  ON MODEDATASHARE_60
  FOR EACH ROW
  begin   select modeDataShare_60_id.nextval into :new.id from dual;   end;
/

