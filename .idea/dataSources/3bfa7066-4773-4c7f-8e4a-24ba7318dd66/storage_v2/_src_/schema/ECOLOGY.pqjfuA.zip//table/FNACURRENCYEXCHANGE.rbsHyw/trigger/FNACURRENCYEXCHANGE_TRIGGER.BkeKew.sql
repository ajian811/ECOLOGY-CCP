CREATE TRIGGER FNACURRENCYEXCHANGE_TRIGGER
  BEFORE INSERT
  ON FNACURRENCYEXCHANGE
  FOR EACH ROW
  begin select FnaCurrencyExchange_id.nextval into :new.id from dual; end;
/

