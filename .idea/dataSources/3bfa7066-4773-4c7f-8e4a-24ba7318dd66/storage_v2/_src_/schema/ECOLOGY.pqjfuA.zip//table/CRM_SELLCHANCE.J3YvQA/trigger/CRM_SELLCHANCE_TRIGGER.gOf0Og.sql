CREATE TRIGGER CRM_SELLCHANCE_TRIGGER
  BEFORE INSERT
  ON CRM_SELLCHANCE
  FOR EACH ROW
  begin select CRM_SellChance_id.nextval into :new.id from dual; end;
/

