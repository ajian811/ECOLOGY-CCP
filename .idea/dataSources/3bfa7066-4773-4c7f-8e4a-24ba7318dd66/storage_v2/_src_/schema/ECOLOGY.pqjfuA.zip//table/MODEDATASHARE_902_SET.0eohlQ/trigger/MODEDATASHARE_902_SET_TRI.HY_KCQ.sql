CREATE TRIGGER MODEDATASHARE_902_SET_TRI
  BEFORE INSERT
  ON MODEDATASHARE_902_SET
  FOR EACH ROW
  begin   select modeDataShare_902_set_id.nextval into :new.id from dual;   end;
/

