CREATE TRIGGER CPTCODE1_TRIGGER
  BEFORE INSERT
  ON CPTCODE1
  FOR EACH ROW
  begin select cptcode1_ID.nextval into :new.id from dual; end;
/

