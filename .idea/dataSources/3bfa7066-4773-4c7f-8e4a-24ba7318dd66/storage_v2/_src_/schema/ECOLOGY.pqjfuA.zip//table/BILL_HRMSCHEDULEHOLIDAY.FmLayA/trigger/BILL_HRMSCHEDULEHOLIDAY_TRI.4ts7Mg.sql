CREATE TRIGGER BILL_HRMSCHEDULEHOLIDAY_TRI
  BEFORE INSERT
  ON BILL_HRMSCHEDULEHOLIDAY
  FOR EACH ROW
  begin select Bill_HrmScheduleHoliday_id.nextval INTO :new.id from dual; end;
/

