CREATE TRIGGER BBPMAPPPLAN_TRIGGER
  BEFORE INSERT
  ON BILLBPMAPPROVEPLAN
  FOR EACH ROW
  begin select BBPMAppPlan_id.nextval into :new.id from dual; end;
/

