CREATE TRIGGER CPTBORROWBUFFER_TRIGGER
  BEFORE INSERT
  ON CPTBORROWBUFFER
  FOR EACH ROW
  begin select CptBorrowBuffer_id.nextval into :new.id from dual; end;
/

