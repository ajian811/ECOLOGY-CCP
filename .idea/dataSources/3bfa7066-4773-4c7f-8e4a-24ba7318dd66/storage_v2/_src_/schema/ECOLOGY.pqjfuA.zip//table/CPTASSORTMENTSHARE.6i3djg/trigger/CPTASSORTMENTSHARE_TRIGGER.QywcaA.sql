CREATE TRIGGER CPTASSORTMENTSHARE_TRIGGER
  BEFORE INSERT
  ON CPTASSORTMENTSHARE
  FOR EACH ROW
  begin select CptAssortmentShare_id.nextval into :new.id from dual; end;
/

