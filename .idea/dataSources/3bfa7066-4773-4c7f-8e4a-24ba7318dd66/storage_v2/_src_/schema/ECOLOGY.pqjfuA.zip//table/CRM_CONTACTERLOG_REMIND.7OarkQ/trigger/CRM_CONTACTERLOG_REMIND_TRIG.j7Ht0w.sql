CREATE TRIGGER CRM_CONTACTERLOG_REMIND_TRIG
  BEFORE INSERT
  ON CRM_CONTACTERLOG_REMIND
  FOR EACH ROW
  begin select CRM_ContacterLog_Remind_id.nextval into :new.id from dual; end;
/

