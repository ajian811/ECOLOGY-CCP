CREATE TRIGGER CRM_CUS_LABEL_TRI
  BEFORE INSERT
  ON CRM_CUSTOMER_LABEL
  FOR EACH ROW
  begin select CRM_cus_label_id.nextval into :new.id from dual; end;
/

