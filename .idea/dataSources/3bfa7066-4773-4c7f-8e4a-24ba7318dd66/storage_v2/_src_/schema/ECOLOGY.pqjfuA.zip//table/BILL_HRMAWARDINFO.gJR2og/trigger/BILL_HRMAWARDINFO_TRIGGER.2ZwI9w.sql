CREATE TRIGGER BILL_HRMAWARDINFO_TRIGGER
  BEFORE INSERT
  ON BILL_HRMAWARDINFO
  FOR EACH ROW
  begin select Bill_HrmAwardInfo_id.nextval INTO :new.id from dual; end;
/

