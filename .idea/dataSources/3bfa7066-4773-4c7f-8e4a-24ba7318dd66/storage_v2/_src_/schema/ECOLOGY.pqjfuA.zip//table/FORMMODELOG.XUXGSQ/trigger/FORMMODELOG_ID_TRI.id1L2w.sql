CREATE TRIGGER FORMMODELOG_ID_TRI
  BEFORE INSERT
  ON FORMMODELOG
  FOR EACH ROW
  begin select FormModeLog_id.nextval into :new.id from dual; end;
/

