CREATE TRIGGER FM_10_DT3_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_10_DT3
  FOR EACH ROW
  begin    select fm_10_DT3_ID.nextval into :new.id from dual;  end;
/

