CREATE TRIGGER FNABORROWINFOAMOUNTLOG_TRIGGER
  BEFORE INSERT
  ON FNABORROWINFOAMOUNTLOG
  FOR EACH ROW
  begin select seq_FnaBorrowInfoAmountLog_id.nextval into :new.id from dual; end;
/

