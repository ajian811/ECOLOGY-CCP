CREATE TRIGGER DOCDETAIL_GETPINYIN
  BEFORE INSERT OR UPDATE OF DOCSUBJECT
  ON DOCDETAIL
  FOR EACH ROW
  begin select Lower(getpinyin((:new.docsubject))) into :new.ecology_pinyin_search from dual; end;
/

