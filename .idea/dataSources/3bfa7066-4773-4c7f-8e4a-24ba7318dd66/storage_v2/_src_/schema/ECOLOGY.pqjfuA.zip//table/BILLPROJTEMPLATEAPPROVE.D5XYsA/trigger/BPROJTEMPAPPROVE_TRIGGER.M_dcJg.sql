CREATE TRIGGER BPROJTEMPAPPROVE_TRIGGER
  BEFORE INSERT
  ON BILLPROJTEMPLATEAPPROVE
  FOR EACH ROW
  begin select BProjTempApprove_id.nextval into :new.id from dual; end;
/

