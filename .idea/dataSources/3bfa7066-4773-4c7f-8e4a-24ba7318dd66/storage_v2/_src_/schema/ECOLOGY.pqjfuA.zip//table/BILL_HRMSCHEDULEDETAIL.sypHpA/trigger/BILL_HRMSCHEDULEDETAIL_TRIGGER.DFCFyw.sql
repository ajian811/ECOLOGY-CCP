CREATE TRIGGER BILL_HRMSCHEDULEDETAIL_TRIGGER
  BEFORE INSERT
  ON BILL_HRMSCHEDULEDETAIL
  FOR EACH ROW
  begin select Bill_HrmScheduleDetail_id.nextval into :new.id from dual; end;
/

