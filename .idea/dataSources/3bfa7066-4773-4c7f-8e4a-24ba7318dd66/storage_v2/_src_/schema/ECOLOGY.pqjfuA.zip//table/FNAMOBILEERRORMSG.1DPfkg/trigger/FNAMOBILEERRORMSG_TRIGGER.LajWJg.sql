CREATE TRIGGER FNAMOBILEERRORMSG_TRIGGER
  BEFORE INSERT
  ON FNAMOBILEERRORMSG
  FOR EACH ROW
  begin select seq_FnaMobileErrorMsg_ID.nextval into :new.id from dual; end;
/

