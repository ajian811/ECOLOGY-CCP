CREATE TRIGGER CPTCAPITALMODIFY_TRIGGER
  BEFORE INSERT
  ON CPTCAPITALMODIFY
  FOR EACH ROW
  begin select CptCapitalModify_id.nextval into :new.id from dual; end;
/

