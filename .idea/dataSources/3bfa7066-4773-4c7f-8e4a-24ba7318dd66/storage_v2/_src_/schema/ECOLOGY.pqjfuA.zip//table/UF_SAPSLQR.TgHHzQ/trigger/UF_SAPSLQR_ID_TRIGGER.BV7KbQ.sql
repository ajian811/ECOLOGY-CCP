CREATE TRIGGER UF_SAPSLQR_ID_TRIGGER
  BEFORE INSERT
  ON UF_SAPSLQR
  FOR EACH ROW
  begin select uf_sapslqr_Id.nextval into :new.id from dual; end;
/

