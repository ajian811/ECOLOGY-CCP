CREATE TRIGGER BILL_HRMHIRE_TRIGGER
  BEFORE INSERT
  ON BILL_HRMHIRE
  FOR EACH ROW
  begin select Bill_HrmHire_id.nextval INTO :new.id from dual; end;
/

