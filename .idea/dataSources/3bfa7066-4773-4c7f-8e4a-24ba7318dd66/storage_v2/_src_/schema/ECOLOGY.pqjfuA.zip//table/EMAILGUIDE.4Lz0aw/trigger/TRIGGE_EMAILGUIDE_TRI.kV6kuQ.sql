CREATE TRIGGER TRIGGE_EMAILGUIDE_TRI
  BEFORE INSERT
  ON EMAILGUIDE
  FOR EACH ROW
  begin select emailGuide_id.nextval into :new.id from dual; end;
/

