CREATE TRIGGER CPTSEARCHDEFINITION_TRIGGER
  BEFORE INSERT
  ON CPTSEARCHDEFINITION
  FOR EACH ROW
  begin select CptSearchDefinition_id.nextval into :new.id from dual; end;
/

