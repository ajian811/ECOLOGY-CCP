CREATE TRIGGER TRI_COW_DIS_BYDIS
  AFTER INSERT
  ON COWORK_DISCUSS
  FOR EACH ROW
  Declare discussant_1 integer; coworkid_1 integer; begin discussant_1 := :new.discussant; coworkid_1 := :new.coworkid;  update cowork_items set lastdiscussant=discussant_1 where id=coworkid_1; end;
/

