CREATE TRIGGER CPT_CPTCARDTAB_TRIGGER
  BEFORE INSERT
  ON CPT_CPTCARDTAB
  FOR EACH ROW
  begin select cpt_cptcardtab_ID.nextval into :new.id from dual; end;
/

