CREATE TRIGGER EXP_FIELDMAP_CS_TRI
  BEFORE INSERT
  ON EXP_FIELDMAP_CS
  FOR EACH ROW
  begin select exp_FieldMap_cs_id.nextval into :new.id from dual; end;
/

