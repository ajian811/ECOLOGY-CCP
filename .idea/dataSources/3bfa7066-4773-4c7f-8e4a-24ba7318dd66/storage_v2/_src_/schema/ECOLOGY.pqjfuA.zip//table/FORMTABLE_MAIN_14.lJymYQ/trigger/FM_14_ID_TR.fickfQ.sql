CREATE TRIGGER FM_14_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_14
  FOR EACH ROW
  begin 
   select fm_14_ID.nextval into :new.id from dual; 
 end;
/

