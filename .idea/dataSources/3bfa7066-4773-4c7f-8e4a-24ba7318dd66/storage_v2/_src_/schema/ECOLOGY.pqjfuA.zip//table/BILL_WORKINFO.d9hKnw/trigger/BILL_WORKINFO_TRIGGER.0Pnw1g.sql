CREATE TRIGGER BILL_WORKINFO_TRIGGER
  BEFORE INSERT
  ON BILL_WORKINFO
  FOR EACH ROW
  begin select bill_workinfo_id.nextval INTO :new.id from dual; end;
/

