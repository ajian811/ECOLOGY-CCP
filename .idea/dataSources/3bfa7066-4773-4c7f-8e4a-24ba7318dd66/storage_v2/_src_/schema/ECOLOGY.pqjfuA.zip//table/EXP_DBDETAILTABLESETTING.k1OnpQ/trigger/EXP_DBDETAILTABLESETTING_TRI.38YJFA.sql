CREATE TRIGGER EXP_DBDETAILTABLESETTING_TRI
  BEFORE INSERT
  ON EXP_DBDETAILTABLESETTING
  FOR EACH ROW
  begin select exp_dbdetailtablesetting_id.nextval into :new.id from dual; end;
/

