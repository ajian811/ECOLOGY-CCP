CREATE TRIGGER EXP_FTPDETAIL_TRI
  BEFORE INSERT
  ON EXP_FTPDETAIL
  FOR EACH ROW
  begin select exp_ftpdetail_id.nextval into :new.id from dual; end;
/

