CREATE TRIGGER CPTCAPITALGROUP_TRIGGER
  BEFORE INSERT
  ON CPTCAPITALGROUP
  FOR EACH ROW
  begin select CptCapitalGroup_id.nextval into :new.id from dual; end;
/

