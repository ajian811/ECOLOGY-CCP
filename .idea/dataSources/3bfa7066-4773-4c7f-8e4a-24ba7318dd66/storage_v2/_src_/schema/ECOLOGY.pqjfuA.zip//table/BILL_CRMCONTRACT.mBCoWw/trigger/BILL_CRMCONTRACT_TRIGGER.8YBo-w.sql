CREATE TRIGGER BILL_CRMCONTRACT_TRIGGER
  BEFORE INSERT
  ON BILL_CRMCONTRACT
  FOR EACH ROW
  begin select Bill_crmcontract_id.nextval into :new.id from dual; end;
/

