CREATE TRIGGER CRM_DELIVERYTYPE_TRIGGER
  BEFORE INSERT
  ON CRM_DELIVERYTYPE
  FOR EACH ROW
  begin select CRM_DeliveryType_id.nextval into :new.id from dual; end;
/

