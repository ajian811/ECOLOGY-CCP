CREATE TRIGGER DOCDOCUMENTSIGNATURE_TRIGGER
  BEFORE INSERT
  ON DOCDOCUMENTSIGNATURE
  FOR EACH ROW
  begin select DocDocumentSignature_id.nextval into :new.id from dual; end;
/

