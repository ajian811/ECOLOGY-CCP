CREATE TRIGGER EXPANDBASERIGHTEXPRESSIONS_TRI
  BEFORE INSERT
  ON EXPANDBASERIGHTEXPRESSIONS
  FOR EACH ROW
  begin select expandBaseRightExpressions_ID.nextval into :new.id from dual; end;
/

