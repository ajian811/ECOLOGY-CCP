CREATE TRIGGER BILL_BOHAIEVECTION_TRIGGER
  BEFORE INSERT
  ON BILL_BOHAIEVECTION
  FOR EACH ROW
  begin select Bill_BoHaiEvection_id.nextval into :new.id from dual; end;
/

