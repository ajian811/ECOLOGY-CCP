CREATE TRIGGER FVXMLCONTENTDSET_TRIGGER
  BEFORE INSERT
  ON FNAVOUCHERXMLCONTENTDSET
  FOR EACH ROW
  begin select seq_fVXmlContentDset_id.nextval into :new.id from dual; end;
/

