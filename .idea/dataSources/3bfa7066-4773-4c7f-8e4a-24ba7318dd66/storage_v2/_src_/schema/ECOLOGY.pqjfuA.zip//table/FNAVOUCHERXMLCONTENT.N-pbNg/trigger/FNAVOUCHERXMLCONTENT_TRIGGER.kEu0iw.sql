CREATE TRIGGER FNAVOUCHERXMLCONTENT_TRIGGER
  BEFORE INSERT
  ON FNAVOUCHERXMLCONTENT
  FOR EACH ROW
  begin select seq_fnaVoucherXmlContent_id.nextval into :new.id from dual; end;
/

