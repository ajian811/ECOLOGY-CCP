CREATE TRIGGER FM_3_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_3
  FOR EACH ROW
  begin 
   select fm_3_ID.nextval into :new.id from dual; 
 end;
/

