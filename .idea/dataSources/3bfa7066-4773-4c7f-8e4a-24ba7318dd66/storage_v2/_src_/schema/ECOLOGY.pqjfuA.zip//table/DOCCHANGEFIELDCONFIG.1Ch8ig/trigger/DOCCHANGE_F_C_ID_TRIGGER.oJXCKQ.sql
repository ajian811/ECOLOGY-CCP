CREATE TRIGGER DOCCHANGE_F_C_ID_TRIGGER
  BEFORE INSERT
  ON DOCCHANGEFIELDCONFIG
  FOR EACH ROW
  begin select DocChangeFieldConfig_Id.nextval into :new.id from dual; end;
/

