CREATE TRIGGER UF_VGM1_DT2_ID_TR
  BEFORE INSERT
  ON UF_VGM1_DT2
  FOR EACH ROW
  begin select uf_VGM1_dt2_Id.nextval into :new.id from dual; end;
/

