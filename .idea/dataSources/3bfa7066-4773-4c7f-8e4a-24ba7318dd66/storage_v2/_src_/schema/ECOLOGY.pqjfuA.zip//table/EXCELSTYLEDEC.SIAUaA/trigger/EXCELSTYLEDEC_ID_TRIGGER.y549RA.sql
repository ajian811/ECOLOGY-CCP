CREATE TRIGGER EXCELSTYLEDEC_ID_TRIGGER
  BEFORE INSERT
  ON EXCELSTYLEDEC
  FOR EACH ROW
  begin select excelStyleDec_id.nextval into :new.id from dual; end;
/

