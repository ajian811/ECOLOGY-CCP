CREATE TRIGGER DOCSUBCATFTPCONFIG_TRIGGER
  BEFORE INSERT
  ON DOCSUBCATFTPCONFIG
  FOR EACH ROW
  begin select DocSubCatFTPConfig_id.nextval into :new.id from dual; end;
/

