CREATE TRIGGER DOCSECCATFTPCONFIG_TRIGGER
  BEFORE INSERT
  ON DOCSECCATFTPCONFIG
  FOR EACH ROW
  begin select DocSecCatFTPConfig_id.nextval into :new.id from dual; end;
/

