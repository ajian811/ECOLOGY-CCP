CREATE TRIGGER BILL_MEETING_TRI
  BEFORE INSERT
  ON BILL_MEETING
  FOR EACH ROW
  begin select Bill_Meeting_id.nextval into :new.id from dual; end;
/

