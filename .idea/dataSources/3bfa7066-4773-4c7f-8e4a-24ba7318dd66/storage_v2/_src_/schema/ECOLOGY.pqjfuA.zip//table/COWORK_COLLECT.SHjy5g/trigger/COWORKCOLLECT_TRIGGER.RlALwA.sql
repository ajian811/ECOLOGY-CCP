CREATE TRIGGER COWORKCOLLECT_TRIGGER
  BEFORE INSERT
  ON COWORK_COLLECT
  FOR EACH ROW
  begin select coworkcollect_seq.nextval into:new.id from sys.dual; end;
/

