CREATE TRIGGER EXTENDLOGIN_ID_TRIGGER
  BEFORE INSERT
  ON EXTENDLOGIN
  FOR EACH ROW
  begin select extendLogin_Id.nextval into :new.id from dual; end ;
/

