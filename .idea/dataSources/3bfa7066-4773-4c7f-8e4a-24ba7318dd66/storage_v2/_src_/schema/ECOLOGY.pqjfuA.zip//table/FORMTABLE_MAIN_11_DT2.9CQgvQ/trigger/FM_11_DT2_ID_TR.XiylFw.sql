CREATE TRIGGER FM_11_DT2_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_11_DT2
  FOR EACH ROW
  begin    select fm_11_DT2_ID.nextval into :new.id from dual;  end;
/

