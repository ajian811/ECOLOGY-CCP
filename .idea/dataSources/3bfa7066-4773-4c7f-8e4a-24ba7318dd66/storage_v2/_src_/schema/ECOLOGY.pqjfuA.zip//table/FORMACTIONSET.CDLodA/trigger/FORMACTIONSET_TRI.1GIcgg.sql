CREATE TRIGGER FORMACTIONSET_TRI
  BEFORE INSERT
  ON FORMACTIONSET
  FOR EACH ROW
  begin select formactionset_seq.nextval into :new.id from dual; end;
/

