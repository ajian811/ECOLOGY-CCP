CREATE TRIGGER FM_15_DT1_ID_TR
  BEFORE INSERT
  ON FORMTABLE_MAIN_15_DT1
  FOR EACH ROW
  begin    select fm_15_DT1_ID.nextval into :new.id from dual;  end;
/

