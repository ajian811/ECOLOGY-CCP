CREATE TRIGGER BILL_DISCUSS_TRIGGER
  BEFORE INSERT
  ON BILL_DISCUSS
  FOR EACH ROW
  begin select bill_Discuss_id.nextval INTO :new.id from dual; end;
/

