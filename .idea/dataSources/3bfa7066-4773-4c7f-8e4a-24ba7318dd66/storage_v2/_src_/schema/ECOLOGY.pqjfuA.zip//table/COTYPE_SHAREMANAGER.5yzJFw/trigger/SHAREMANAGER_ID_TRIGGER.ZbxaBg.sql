CREATE TRIGGER SHAREMANAGER_ID_TRIGGER
  BEFORE INSERT
  ON COTYPE_SHAREMANAGER
  FOR EACH ROW
  begin select sharemanager_Id.nextval into :new.id from dual; end;
/

